import React from 'react';
import { Mic, BookOpen, Settings } from 'lucide-react';
import { AppScreen } from '../types';

interface BottomNavProps {
  currentScreen: AppScreen;
  onNavigate: (screen: AppScreen) => void;
  noteCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentScreen,
  onNavigate,
  noteCount,
}) => {
  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-40 bg-[#FAF7F2]/95 backdrop-blur-md border-t border-amber-200/60 pb-safe shadow-lg"
      aria-label="Bottom Navigation"
    >
      <div className="max-w-md mx-auto grid grid-cols-3 items-center h-16 px-4">
        {/* Record Tab */}
        <button
          type="button"
          onClick={() => onNavigate('home')}
          className={`group flex flex-col items-center justify-center h-full min-h-[44px] transition-all relative ${
            currentScreen === 'home' || currentScreen === 'recording'
              ? 'text-purple-700 font-semibold'
              : 'text-stone-500 hover:text-stone-800'
          }`}
        >
          <div
            className={`w-10 h-7 rounded-full flex items-center justify-center transition-colors ${
              currentScreen === 'home' || currentScreen === 'recording'
                ? 'bg-purple-100 text-purple-700'
                : 'group-hover:bg-amber-100/60'
            }`}
          >
            <Mic className="w-4 h-4 stroke-[2.2]" />
          </div>
          <span className="text-[11px] mt-0.5 tracking-tight">Record</span>
        </button>

        {/* My Notes Tab */}
        <button
          type="button"
          onClick={() => onNavigate('my-notes')}
          className={`group flex flex-col items-center justify-center h-full min-h-[44px] transition-all relative ${
            currentScreen === 'my-notes' || currentScreen === 'transcript'
              ? 'text-purple-700 font-semibold'
              : 'text-stone-500 hover:text-stone-800'
          }`}
        >
          <div
            className={`w-10 h-7 rounded-full flex items-center justify-center transition-colors relative ${
              currentScreen === 'my-notes' || currentScreen === 'transcript'
                ? 'bg-purple-100 text-purple-700'
                : 'group-hover:bg-amber-100/60'
            }`}
          >
            <BookOpen className="w-4 h-4 stroke-[2.2]" />
            {noteCount > 0 && (
              <span className="absolute -top-1 -right-1 px-1.5 py-0.2 min-w-[16px] text-[10px] font-bold rounded-full bg-amber-400 text-amber-950 flex items-center justify-center shadow-xs">
                {noteCount > 99 ? '99+' : noteCount}
              </span>
            )}
          </div>
          <span className="text-[11px] mt-0.5 tracking-tight">My Notes</span>
        </button>

        {/* Settings Tab */}
        <button
          type="button"
          onClick={() => onNavigate('settings')}
          className={`group flex flex-col items-center justify-center h-full min-h-[44px] transition-all relative ${
            currentScreen === 'settings'
              ? 'text-purple-700 font-semibold'
              : 'text-stone-500 hover:text-stone-800'
          }`}
        >
          <div
            className={`w-10 h-7 rounded-full flex items-center justify-center transition-colors ${
              currentScreen === 'settings'
                ? 'bg-purple-100 text-purple-700'
                : 'group-hover:bg-amber-100/60'
            }`}
          >
            <Settings className="w-4 h-4 stroke-[2.2]" />
          </div>
          <span className="text-[11px] mt-0.5 tracking-tight">Settings</span>
        </button>
      </div>
    </nav>
  );
};
