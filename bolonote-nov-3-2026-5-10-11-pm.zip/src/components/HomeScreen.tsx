import React from 'react';
import { Mic, Globe, Clock, ChevronRight, Play, Volume2, Sparkles, CheckCircle2 } from 'lucide-react';
import { Language, Note } from '../types';

interface HomeScreenProps {
  selectedLanguage: Language;
  onOpenLanguageSelector: () => void;
  onStartRecording: () => void;
  recentNotes: Note[];
  onSelectNote: (note: Note) => void;
  onViewAllNotes: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  selectedLanguage,
  onOpenLanguageSelector,
  onStartRecording,
  recentNotes,
  onSelectNote,
  onViewAllNotes,
}) => {
  // Format dynamic time-of-day greeting
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  const formattedDate = new Intl.DateTimeFormat('en-IN', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
  }).format(new Date());

  return (
    <div className="flex flex-col min-h-[calc(100vh-4rem)] pb-24 px-4 max-w-md mx-auto">
      {/* Top Brand Bar & Greeting */}
      <header className="pt-6 pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-300 via-amber-200 to-purple-200 flex items-center justify-center shadow-xs border border-amber-200">
              <span className="text-xl">🎙️</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="text-xl font-bold tracking-tight text-stone-900">BoloNote</h1>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-purple-100 text-purple-700">
                  v3.0 Ready
                </span>
              </div>
              <p className="text-xs text-stone-500 font-medium">बोलो नोट · India</p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs font-semibold text-stone-600 block">{formattedDate}</span>
            <span className="text-[11px] text-amber-700 font-medium bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200/60">
              Offline Ready
            </span>
          </div>
        </div>

        {/* Greeting Banner */}
        <div className="mt-5 p-4 rounded-3xl bg-gradient-to-r from-amber-100/90 via-amber-50/80 to-purple-50/90 border border-amber-200/80 shadow-xs">
          <p className="text-xs font-semibold text-amber-800 uppercase tracking-wider">
            {getGreeting()}
          </p>
          <h2 className="text-lg font-bold text-stone-900 mt-0.5 leading-snug">
            Speak naturally. Your words become notes.
          </h2>
          <p className="text-xs text-stone-600 mt-1">
            Tap the mic to speak naturally. Voice notes across 10+ Indian languages.
          </p>
        </div>
      </header>

      {/* Language Selector Trigger Card */}
      <section className="mb-6">
        <button
          type="button"
          onClick={onOpenLanguageSelector}
          className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-white border border-stone-200/80 shadow-xs hover:border-amber-300 transition-all active:scale-[0.99]"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-purple-100/80 text-purple-700 flex items-center justify-center">
              <Globe className="w-4 h-4" />
            </div>
            <div className="text-left">
              <span className="text-[11px] font-medium text-stone-400 uppercase tracking-wider block">
                Recording Language
              </span>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-stone-900">
                  {selectedLanguage.name}
                </span>
                <span className="text-xs text-stone-500 font-medium">
                  ({selectedLanguage.native})
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1 text-xs font-semibold text-purple-700 bg-purple-50 px-2.5 py-1 rounded-xl">
            <span>Change</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </div>
        </button>
      </section>

      {/* Central Large Microphone Button */}
      <section className="my-auto py-6 flex flex-col items-center justify-center text-center">
        <div className="relative flex items-center justify-center">
          {/* Outer Pulsing Glow Rings */}
          <div className="absolute -inset-4 rounded-full bg-gradient-to-r from-amber-200/50 via-purple-200/40 to-amber-200/50 blur-md animate-warm-pulse pointer-events-none" />
          <div className="absolute -inset-1.5 rounded-full bg-gradient-to-tr from-amber-300/60 to-purple-300/60 opacity-80 pointer-events-none" />

          {/* Primary Record Button */}
          <button
            type="button"
            onClick={onStartRecording}
            className="relative w-36 h-36 rounded-full bg-gradient-to-tr from-amber-300 via-amber-200 to-purple-200 p-1 shadow-xl hover:shadow-2xl active:scale-95 transition-all duration-200 group flex items-center justify-center border-4 border-white focus:outline-none focus:ring-4 focus:ring-amber-300/50 cursor-pointer"
            aria-label="Tap to record"
          >
            <div className="w-full h-full rounded-full bg-white/95 flex flex-col items-center justify-center text-stone-900 group-hover:bg-amber-50/70 transition-colors">
              <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-amber-400 to-purple-400 text-stone-950 flex items-center justify-center shadow-md mb-1.5 group-hover:scale-105 transition-transform">
                <Mic className="w-7 h-7 text-stone-950 stroke-[2.3]" />
              </div>
              <span className="text-xs font-extrabold tracking-tight text-stone-900">
                Tap to record
              </span>
            </div>
          </button>
        </div>

        {/* Recording Note Hint */}
        <div className="mt-4 flex items-center gap-1.5 text-xs text-stone-500 font-medium">
          <Mic className="w-3.5 h-3.5 text-amber-600" />
          <span>Tap to start recording</span>
        </div>
      </section>

      {/* Recent Notes Section */}
      <section className="mt-auto pt-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-bold text-stone-900">Recent Notes</h3>
          {recentNotes.length > 0 && (
            <button
              type="button"
              onClick={onViewAllNotes}
              className="text-xs font-semibold text-purple-700 hover:text-purple-900 transition-colors"
            >
              View all ({recentNotes.length})
            </button>
          )}
        </div>

        {recentNotes.length === 0 ? (
          <div className="p-6 rounded-3xl bg-amber-50/60 border border-dashed border-amber-200 text-center">
            <p className="text-xs text-stone-600 font-medium">No voice notes yet.</p>
            <p className="text-xs text-stone-400 mt-1">
              Tap the microphone above to speak your first note!
            </p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {recentNotes.slice(0, 2).map((note) => (
              <div
                key={note.id}
                onClick={() => onSelectNote(note)}
                className="w-full p-3.5 rounded-2xl bg-white border border-stone-200/80 shadow-xs hover:border-purple-300 transition-all cursor-pointer text-left group"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm font-bold text-stone-900 truncate group-hover:text-purple-800 transition-colors">
                      {note.title || 'Untitled Voice Note'}
                    </h4>
                    <p className="text-xs text-stone-500 mt-1 line-clamp-1">
                      {note.transcript || '(No transcript entered yet)'}
                    </p>
                  </div>
                  <div className="w-7 h-7 rounded-full bg-purple-50 text-purple-700 flex items-center justify-center shrink-0">
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </div>

                <div className="flex items-center gap-2 mt-2 pt-2 border-t border-stone-100 text-[11px] text-stone-400 font-medium">
                  <span className="text-stone-600 font-semibold">{note.language}</span>
                  <span>·</span>
                  <span>{new Date(note.createdAt).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}</span>
                  <span>·</span>
                  <span>{note.durationSeconds}s</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
