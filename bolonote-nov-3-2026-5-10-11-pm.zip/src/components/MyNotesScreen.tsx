import React, { useState, useRef } from 'react';
import {
  Search,
  Trash2,
  Edit2,
  Copy,
  Volume2,
  VolumeX,
  Play,
  Pause,
  X,
  Calendar,
  Clock,
  Mic,
  Check,
  Share2,
  Save,
  Download,
} from 'lucide-react';
import { Note } from '../types';
import { playTextToSpeech } from '../utils/audio';
import { exportNotesAsPdf, exportNotesAsTxt } from '../utils/export';
import { ExportSelectionModal } from './ExportSelectionModal';

interface MyNotesScreenProps {
  notes: Note[];
  onUpdateNote: (note: Note) => void;
  onDeleteNote: (id: string) => void;
  onNavigateToRecord: () => void;
}

export const MyNotesScreen: React.FC<MyNotesScreenProps> = ({
  notes,
  onUpdateNote,
  onDeleteNote,
  onNavigateToRecord,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLanguageFilter, setSelectedLanguageFilter] = useState<string>('All');
  const [activeNote, setActiveNote] = useState<Note | null>(null);
  const [isEditingActiveNote, setIsEditingActiveNote] = useState(false);
  const [editTitle, setEditTitle] = useState('');
  const [editTranscript, setEditTranscript] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isPlayingAudioId, setIsPlayingAudioId] = useState<string | null>(null);
  const [isListeningSpeech, setIsListeningSpeech] = useState(false);
  const [exportModal, setExportModal] = useState<{
    isOpen: boolean;
    format: 'pdf' | 'txt';
  }>({
    isOpen: false,
    format: 'pdf',
  });

  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);
  const stopTtsRef = useRef<(() => void) | null>(null);

  const handleExportSelected = async (selectedNotes: Note[], format: 'pdf' | 'txt') => {
    if (format === 'pdf') {
      return await exportNotesAsPdf(selectedNotes);
    } else {
      return await exportNotesAsTxt(selectedNotes);
    }
  };

  // Filter notes
  const filteredNotes = notes.filter((note) => {
    const matchesSearch =
      note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.transcript.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesLanguage =
      selectedLanguageFilter === 'All' || note.language.toLowerCase().includes(selectedLanguageFilter.toLowerCase());
    return matchesSearch && matchesLanguage;
  });

  // Extract unique languages present in saved notes
  const uniqueLanguages = ['All', ...Array.from(new Set(notes.map((n) => n.language)))];

  // Quick Copy
  const handleQuickCopy = async (note: Note, e?: React.MouseEvent) => {
    e?.stopPropagation();
    try {
      await navigator.clipboard.writeText(note.transcript);
      setCopiedId(note.id);
      setTimeout(() => setCopiedId(null), 1800);
    } catch {
      // Fallback
    }
  };

  // Quick Play Audio
  const handleTogglePlayAudio = (note: Note, e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (!note.audioBase64) return;

    if (isPlayingAudioId === note.id) {
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
      }
      setIsPlayingAudioId(null);
    } else {
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
      }
      const audio = new Audio(note.audioBase64);
      audioPlayerRef.current = audio;
      audio.onended = () => setIsPlayingAudioId(null);
      audio.play().catch(() => setIsPlayingAudioId(null));
      setIsPlayingAudioId(note.id);
    }
  };

  // Open note details
  const handleOpenNote = (note: Note) => {
    setActiveNote(note);
    setEditTitle(note.title);
    setEditTranscript(note.transcript);
    setIsEditingActiveNote(false);
  };

  // Save edits
  const handleSaveEdit = () => {
    if (!activeNote) return;
    const updated: Note = {
      ...activeNote,
      title: editTitle.trim() || activeNote.title,
      transcript: editTranscript.trim(),
    };
    onUpdateNote(updated);
    setActiveNote(updated);
    setIsEditingActiveNote(false);
  };

  // Listen in modal
  const handleModalListen = () => {
    if (isListeningSpeech) {
      stopTtsRef.current?.();
      setIsListeningSpeech(false);
      return;
    }
    if (!activeNote) return;

    const cancelFn = playTextToSpeech(
      isEditingActiveNote ? editTranscript : activeNote.transcript,
      activeNote.languageCode || 'hi-IN',
      () => setIsListeningSpeech(true),
      () => setIsListeningSpeech(false),
      () => setIsListeningSpeech(false)
    );
    stopTtsRef.current = cancelFn;
  };

  // Delete note
  const handleDelete = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (window.confirm('Are you sure you want to delete this voice note?')) {
      if (isPlayingAudioId === id && audioPlayerRef.current) {
        audioPlayerRef.current.pause();
        setIsPlayingAudioId(null);
      }
      if (activeNote?.id === id) {
        setActiveNote(null);
      }
      onDeleteNote(id);
    }
  };

  const formatDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return dateStr;
    }
  };

  return (
    <div className="flex flex-col min-h-screen pb-24 px-4 max-w-md mx-auto">
      {/* Top Header */}
      <div className="pt-6 pb-3">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold tracking-tight text-stone-900">My Notes</h1>
            <p className="text-xs text-stone-500 font-medium">
              {notes.length} {notes.length === 1 ? 'voice note' : 'voice notes'} saved
            </p>
          </div>

          <div className="flex items-center gap-2">
            {notes.length > 0 && (
              <button
                type="button"
                onClick={() => setExportModal({ isOpen: true, format: 'pdf' })}
                className="px-3 py-1.5 rounded-full bg-white border border-stone-200 hover:border-amber-300 text-stone-700 font-bold text-xs flex items-center gap-1.5 shadow-xs hover:bg-stone-50 active:scale-95 transition-all cursor-pointer"
                title="Export selected notes"
              >
                <Download className="w-3.5 h-3.5 text-purple-700" />
                <span>Export</span>
              </button>
            )}

            <button
              type="button"
              onClick={onNavigateToRecord}
              className="px-3.5 py-1.5 rounded-full bg-gradient-to-r from-amber-300 to-purple-200 text-stone-900 font-bold text-xs flex items-center gap-1.5 shadow-xs hover:shadow-sm active:scale-95 transition-all cursor-pointer"
            >
              <Mic className="w-3.5 h-3.5 stroke-[2.2]" />
              <span>New Note</span>
            </button>
          </div>
        </div>

        {/* Search Input */}
        <div className="relative mt-4">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search notes by title or words..."
            className="w-full pl-9 pr-9 py-2.5 rounded-2xl bg-white border border-stone-200/80 focus:border-amber-400 focus:ring-2 focus:ring-amber-200/50 text-stone-900 text-xs font-medium outline-none shadow-xs"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Language Filter Tabs (if more than 1 language present) */}
        {uniqueLanguages.length > 2 && (
          <div className="flex items-center gap-1.5 overflow-x-auto py-2 mt-1 no-scrollbar">
            {uniqueLanguages.map((lang) => (
              <button
                key={lang}
                onClick={() => setSelectedLanguageFilter(lang)}
                className={`px-3 py-1 rounded-full text-[11px] font-semibold whitespace-nowrap transition-colors ${
                  selectedLanguageFilter === lang
                    ? 'bg-purple-100 text-purple-800 border border-purple-300'
                    : 'bg-white text-stone-600 border border-stone-200/80 hover:bg-stone-50'
                }`}
              >
                {lang}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Notes List */}
      <div className="space-y-3 mt-2">
        {filteredNotes.length === 0 ? (
          <div className="p-8 rounded-3xl bg-white border border-dashed border-stone-200 text-center my-6">
            <div className="w-12 h-12 rounded-full bg-amber-100/80 text-amber-800 flex items-center justify-center mx-auto mb-3">
              <Mic className="w-6 h-6 stroke-[2]" />
            </div>
            <h3 className="text-sm font-bold text-stone-800">
              {searchQuery ? 'No matching notes' : 'No notes saved yet'}
            </h3>
            <p className="text-xs text-stone-500 mt-1 max-w-xs mx-auto">
              {searchQuery
                ? `No notes matched "${searchQuery}". Try different keywords.`
                : 'Start speaking in Hindi, English, Bengali, or any Indian language.'}
            </p>
            {!searchQuery && (
              <button
                type="button"
                onClick={onNavigateToRecord}
                className="mt-4 px-4 py-2 bg-amber-400 hover:bg-amber-500 text-stone-950 font-bold text-xs rounded-xl shadow-xs transition-colors"
              >
                Record First Note
              </button>
            )}
          </div>
        ) : (
          filteredNotes.map((note) => {
            const isPlayingThis = isPlayingAudioId === note.id;
            const isCopiedThis = copiedId === note.id;

            return (
              <div
                key={note.id}
                onClick={() => handleOpenNote(note)}
                className="p-4 rounded-3xl bg-white border border-stone-200/80 shadow-xs hover:border-amber-300/80 hover:shadow-sm transition-all cursor-pointer group"
              >
                {/* Header row: Title & Quick Actions */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <h3 className="text-sm font-bold text-stone-900 truncate group-hover:text-purple-800 transition-colors">
                      {note.title || 'Untitled Voice Note'}
                    </h3>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                    {note.audioBase64 && (
                      <button
                        type="button"
                        onClick={(e) => handleTogglePlayAudio(note, e)}
                        className={`w-7 h-7 rounded-full flex items-center justify-center transition-colors ${
                          isPlayingThis
                            ? 'bg-amber-500 text-stone-950 animate-pulse'
                            : 'bg-amber-100 hover:bg-amber-200 text-amber-900'
                        }`}
                        title={isPlayingThis ? 'Pause audio' : 'Play audio'}
                        aria-label={isPlayingThis ? 'Pause audio' : 'Play audio'}
                      >
                        {isPlayingThis ? (
                          <Pause className="w-3.5 h-3.5 fill-current" />
                        ) : (
                          <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                        )}
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={(e) => handleQuickCopy(note, e)}
                      className={`w-7 h-7 rounded-full flex items-center justify-center transition-colors ${
                        isCopiedThis
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-stone-100 hover:bg-stone-200 text-stone-600'
                      }`}
                      title={isCopiedThis ? 'Copied' : 'Copy transcript'}
                      aria-label="Copy transcript"
                    >
                      {isCopiedThis ? (
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={(e) => handleDelete(note.id, e)}
                      className="w-7 h-7 rounded-full bg-stone-100 hover:bg-red-50 hover:text-red-600 flex items-center justify-center text-stone-400 transition-colors"
                      title="Delete note"
                      aria-label="Delete note"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Transcript snippet */}
                <p className="text-xs text-stone-600 mt-2 line-clamp-2 leading-relaxed">
                  {note.transcript || '(Empty note)'}
                </p>

                {/* Metadata row */}
                <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-stone-100 text-[11px] text-stone-400 font-medium">
                  <div className="flex items-center gap-1.5">
                    <span className="font-semibold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-full">
                      {note.language}
                    </span>
                    <span>·</span>
                    <span>{note.durationSeconds}s audio</span>
                  </div>

                  <span>{formatDate(note.createdAt)}</span>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Note Detail & Edit Modal */}
      {activeNote && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/40 backdrop-blur-xs">
          <div className="fixed inset-0" onClick={() => setActiveNote(null)} />

          <div className="relative w-full max-w-md bg-[#FAF7F2] rounded-t-3xl sm:rounded-3xl shadow-2xl border border-amber-100 p-5 max-h-[90vh] flex flex-col z-10 animate-in slide-in-from-bottom duration-200">
            {/* Mobile handle */}
            <div className="w-12 h-1.5 bg-stone-300 rounded-full mx-auto mb-3 sm:hidden" />

            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-amber-200/50">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-purple-100 text-purple-800">
                  {activeNote.language}
                </span>
                <span className="text-xs text-stone-400">
                  {formatDate(activeNote.createdAt)}
                </span>
              </div>

              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setIsEditingActiveNote(!isEditingActiveNote)}
                  className="px-2.5 py-1 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold flex items-center gap-1 transition-colors"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  <span>{isEditingActiveNote ? 'Cancel Edit' : 'Edit'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveNote(null)}
                  className="w-8 h-8 rounded-full bg-stone-100 hover:bg-stone-200 flex items-center justify-center text-stone-600 transition-colors"
                  aria-label="Close"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Modal Body */}
            <div className="overflow-y-auto py-3 space-y-3 flex-1">
              {/* Title */}
              {isEditingActiveNote ? (
                <div>
                  <label className="block text-[10px] font-bold text-stone-400 uppercase mb-1">
                    Title
                  </label>
                  <input
                    type="text"
                    value={editTitle}
                    onChange={(e) => setEditTitle(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-stone-200 text-sm font-bold text-stone-900 outline-none focus:border-amber-400"
                  />
                </div>
              ) : (
                <h2 className="text-lg font-bold text-stone-900">
                  {activeNote.title}
                </h2>
              )}

              {/* Audio player if note has audio */}
              {activeNote.audioBase64 && (
                <div className="p-3 rounded-2xl bg-white border border-amber-200/70 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => handleTogglePlayAudio(activeNote)}
                      className="w-9 h-9 rounded-full bg-amber-100 hover:bg-amber-200 text-amber-900 flex items-center justify-center transition-colors shadow-xs"
                    >
                      {isPlayingAudioId === activeNote.id ? (
                        <Pause className="w-4 h-4 fill-current" />
                      ) : (
                        <Play className="w-4 h-4 fill-current ml-0.5" />
                      )}
                    </button>
                    <div>
                      <p className="text-xs font-bold text-stone-800">Original Voice Clip</p>
                      <p className="text-[11px] text-stone-400 font-mono">
                        {activeNote.durationSeconds} seconds
                      </p>
                    </div>
                  </div>
                  <span className="text-[11px] text-amber-800 font-semibold bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200/50">
                    Recorded Audio
                  </span>
                </div>
              )}

              {/* Transcript Textarea or Display */}
              <div>
                <label className="block text-[10px] font-bold text-stone-400 uppercase mb-1">
                  Transcript
                </label>
                {isEditingActiveNote ? (
                  <textarea
                    rows={6}
                    value={editTranscript}
                    onChange={(e) => setEditTranscript(e.target.value)}
                    className="w-full p-3 rounded-2xl bg-white border border-stone-200 text-xs text-stone-800 leading-relaxed outline-none focus:border-amber-400 resize-none"
                  />
                ) : (
                  <div className="p-4 rounded-2xl bg-white border border-stone-200/80 text-sm text-stone-800 leading-relaxed whitespace-pre-wrap">
                    {activeNote.transcript || '(No transcript content)'}
                  </div>
                )}
              </div>
            </div>

            {/* Modal Actions Footer */}
            <div className="pt-3 border-t border-amber-200/50 flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => handleQuickCopy(activeNote)}
                  className="px-3 py-2 rounded-xl bg-white border border-stone-200 hover:border-amber-300 text-stone-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  {copiedId === activeNote.id ? (
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  <span>{copiedId === activeNote.id ? 'Copied' : 'Copy'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleModalListen}
                  className={`px-3 py-2 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                    isListeningSpeech
                      ? 'bg-purple-100 border-purple-300 text-purple-900 animate-pulse'
                      : 'bg-white border-stone-200 hover:border-amber-300 text-stone-700'
                  }`}
                >
                  {isListeningSpeech ? (
                    <VolumeX className="w-3.5 h-3.5 text-purple-700" />
                  ) : (
                    <Volume2 className="w-3.5 h-3.5 text-purple-700" />
                  )}
                  <span>{isListeningSpeech ? 'Stop' : 'Listen'}</span>
                </button>
              </div>

              <div className="flex items-center gap-1.5">
                {isEditingActiveNote ? (
                  <button
                    type="button"
                    onClick={handleSaveEdit}
                    className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-500 text-stone-950 font-bold text-xs flex items-center gap-1 transition-colors"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Save Changes</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => handleDelete(activeNote.id)}
                    className="px-3 py-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 text-xs font-semibold flex items-center gap-1 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Note Selection Modal for Export */}
      <ExportSelectionModal
        isOpen={exportModal.isOpen}
        format={exportModal.format}
        notes={notes}
        onClose={() => setExportModal((prev) => ({ ...prev, isOpen: false }))}
        onExport={handleExportSelected}
      />
    </div>
  );
};
