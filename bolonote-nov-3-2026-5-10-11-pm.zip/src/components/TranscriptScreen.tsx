import React, { useState, useEffect, useRef } from 'react';
import {
  Save,
  Copy,
  Volume2,
  VolumeX,
  Edit3,
  Play,
  Pause,
  ArrowLeft,
  Check,
  AlertCircle,
  CheckCircle2,
  Loader2,
  Info
} from 'lucide-react';
import { Note, Language } from '../types';
import { playTextToSpeech } from '../utils/audio';

interface TranscriptScreenProps {
  initialTitle: string;
  initialTranscript: string;
  selectedLanguage: Language;
  detectedLanguageName?: string;
  audioBase64?: string;
  durationSeconds: number;
  isTranscribing?: boolean;
  serverTranscriptionStatus?: {
    configured: boolean;
    success: boolean;
    error?: string;
    message?: string;
  };
  onSaveNote: (note: Omit<Note, 'id' | 'createdAt'>) => void;
  onCancel: () => void;
}

export const TranscriptScreen: React.FC<TranscriptScreenProps> = ({
  initialTitle,
  initialTranscript,
  selectedLanguage,
  detectedLanguageName,
  audioBase64,
  durationSeconds,
  isTranscribing = false,
  serverTranscriptionStatus,
  onSaveNote,
  onCancel,
}) => {
  const [title, setTitle] = useState(initialTitle);
  const [transcript, setTranscript] = useState(initialTranscript);
  const [isCopied, setIsCopied] = useState(false);
  const [isListeningSpeech, setIsListeningSpeech] = useState(false);
  const [audioPlaying, setAudioPlaying] = useState(false);
  const [audioCurrentTime, setAudioCurrentTime] = useState(0);

  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const stopTtsRef = useRef<(() => void) | null>(null);

  // Sync transcript when async transcription arrives
  useEffect(() => {
    if (initialTranscript) {
      setTranscript(initialTranscript);
    }
  }, [initialTranscript]);

  // Sync title when initialTitle changes
  useEffect(() => {
    if (initialTitle) {
      setTitle(initialTitle);
    }
  }, [initialTitle]);

  // Audio player events
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleTimeUpdate = () => {
      setAudioCurrentTime(audio.currentTime);
    };

    const handleEnded = () => {
      setAudioPlaying(false);
      setAudioCurrentTime(0);
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('ended', handleEnded);
      audio.pause();
    };
  }, [audioBase64]);

  // Toggle audio playback
  const handleToggleAudioPlay = () => {
    const audio = audioRef.current;
    if (!audio) return;

    if (audioPlaying) {
      audio.pause();
      setAudioPlaying(false);
    } else {
      audio.play().catch((err) => console.error('Audio play error', err));
      setAudioPlaying(true);
    }
  };

  // Copy to clipboard
  const handleCopy = async () => {
    if (!transcript) return;
    try {
      await navigator.clipboard.writeText(transcript);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    } catch {
      // Fallback
      const input = document.createElement('textarea');
      input.value = transcript;
      document.body.appendChild(input);
      input.select();
      document.execCommand('copy');
      document.body.removeChild(input);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    }
  };

  // Listen (Text to Speech)
  const handleToggleListen = () => {
    if (isListeningSpeech) {
      if (stopTtsRef.current) {
        stopTtsRef.current();
        stopTtsRef.current = null;
      }
      setIsListeningSpeech(false);
      return;
    }

    if (!transcript.trim()) return;

    const targetLangCode = selectedLanguage.code === 'auto' ? 'hi-IN' : selectedLanguage.code;
    const cancelFn = playTextToSpeech(
      transcript,
      targetLangCode,
      () => setIsListeningSpeech(true),
      () => setIsListeningSpeech(false),
      () => setIsListeningSpeech(false)
    );
    stopTtsRef.current = cancelFn;
  };

  // Focus textarea when Edit button is clicked
  const handleEditClick = () => {
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  };

  // Save Note
  const handleSave = () => {
    const finalTitle =
      title.trim() ||
      `Voice Note - ${new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}`;
    onSaveNote({
      title: finalTitle,
      transcript: transcript.trim(),
      language: detectedLanguageName || selectedLanguage.name,
      languageCode: selectedLanguage.code,
      durationSeconds,
      audioBase64,
    });
  };

  const wordCount = transcript.trim() ? transcript.trim().split(/\s+/).length : 0;

  return (
    <div className="flex flex-col min-h-screen pb-24 px-4 max-w-md mx-auto">
      {/* Hidden audio element for recorded clip */}
      {audioBase64 && <audio ref={audioRef} src={audioBase64} preload="auto" />}

      {/* Top Header */}
      <div className="pt-6 pb-3 flex items-center justify-between border-b border-amber-200/50">
        <button
          type="button"
          onClick={onCancel}
          className="flex items-center gap-1.5 text-xs font-semibold text-stone-600 hover:text-stone-900 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>

        <h2 className="text-sm font-bold text-stone-900">Note Transcript</h2>

        <button
          type="button"
          onClick={handleSave}
          className="px-3.5 py-1.5 rounded-full bg-amber-400 hover:bg-amber-500 text-stone-950 font-bold text-xs flex items-center gap-1 shadow-xs transition-colors cursor-pointer"
        >
          <Save className="w-3.5 h-3.5" />
          <span>Save</span>
        </button>
      </div>

      {/* Note Title Input */}
      <div className="mt-4">
        <label
          htmlFor="note-title"
          className="block text-[11px] font-bold text-stone-400 uppercase tracking-wider mb-1"
        >
          Note Title
        </label>
        <input
          id="note-title"
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Give your note a title..."
          className="w-full px-3.5 py-2.5 rounded-2xl bg-white border border-stone-200/80 focus:border-amber-400 focus:ring-2 focus:ring-amber-200/50 text-stone-900 font-bold text-base outline-none transition-all shadow-xs"
        />
      </div>

      {/* Language & Metadata Row */}
      <div className="mt-2.5 flex items-center justify-between text-xs">
        <div className="flex items-center gap-1.5">
          <span className="font-semibold text-stone-500">Language:</span>
          <span className="font-bold text-purple-800 bg-purple-100/80 px-2 py-0.5 rounded-full text-[11px]">
            {detectedLanguageName || selectedLanguage.name} ({selectedLanguage.native})
          </span>
        </div>

        <span className="text-stone-400 font-medium">
          {durationSeconds}s audio · {wordCount} {wordCount === 1 ? 'word' : 'words'}
        </span>
      </div>

      {/* Audio Playback Player */}
      {audioBase64 && (
        <div className="mt-4 p-3 rounded-2xl bg-white border border-amber-200/70 shadow-xs flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleToggleAudioPlay}
              className="w-9 h-9 rounded-full bg-amber-100 hover:bg-amber-200 text-amber-900 flex items-center justify-center transition-colors shadow-xs cursor-pointer"
              aria-label={audioPlaying ? 'Pause audio' : 'Play audio'}
            >
              {audioPlaying ? (
                <Pause className="w-4 h-4 fill-current" />
              ) : (
                <Play className="w-4 h-4 fill-current ml-0.5" />
              )}
            </button>
            <div>
              <p className="text-xs font-bold text-stone-800">Your Voice Recording</p>
              <p className="text-[11px] text-stone-500 font-mono">
                {Math.floor(audioCurrentTime)}s / {durationSeconds}s
              </p>
            </div>
          </div>

          <div className="text-[11px] font-semibold text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200/50">
            Original Audio
          </div>
        </div>
      )}

      {/* Dynamic Gnani Prisma STT Status Card */}
      {isTranscribing ? (
        <div className="mt-3 p-3.5 rounded-2xl bg-purple-50 border border-purple-200 text-xs flex items-center gap-2.5 animate-pulse">
          <Loader2 className="w-4 h-4 text-purple-700 animate-spin shrink-0" />
          <div>
            <p className="font-bold text-purple-900">Transcribing with Gnani Prisma v3.0...</p>
            <p className="text-[11px] text-purple-700 mt-0.5">
              Converting audio and recognizing speech in {selectedLanguage.name}...
            </p>
          </div>
        </div>
      ) : serverTranscriptionStatus?.success ? (
        <div className="mt-3 p-3 rounded-2xl bg-emerald-50/90 border border-emerald-200 text-xs flex items-start gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          <div>
            <p className="font-bold text-emerald-900">
              Transcribed via Gnani Prisma v3.0
            </p>
            <p className="text-[11px] text-emerald-700 mt-0.5">
              {transcript
                ? `Speech recognized in ${detectedLanguageName || selectedLanguage.name}. You can edit or save below.`
                : 'Audio processed by Gnani Prisma. No clear speech detected in recording.'}
            </p>
          </div>
        </div>
      ) : serverTranscriptionStatus?.message ? (
        <div className="mt-3 p-3 rounded-2xl bg-amber-50 border border-amber-200 text-xs flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-bold text-amber-900">Gnani Prisma STT Notice</p>
            <p className="text-[11px] text-amber-800 mt-0.5 leading-relaxed">
              {serverTranscriptionStatus.message}
            </p>
          </div>
        </div>
      ) : null}

      {/* Transcript Textarea */}
      <div className="mt-4 flex-1 flex flex-col">
        <div className="flex items-center justify-between mb-1.5">
          <label
            htmlFor="transcript-text"
            className="text-[11px] font-bold text-stone-400 uppercase tracking-wider"
          >
            Recognised Text / Note Content
          </label>
          <span className="text-[11px] text-stone-400">Editable</span>
        </div>

        <textarea
          id="transcript-text"
          ref={textareaRef}
          value={transcript}
          onChange={(e) => setTranscript(e.target.value)}
          placeholder={
            isTranscribing
              ? 'Recognising speech with Gnani Prisma v3.0...'
              : 'Speak naturally or write your note here...'
          }
          rows={7}
          className="w-full flex-1 p-4 rounded-3xl bg-white border border-stone-200/80 focus:border-amber-400 focus:ring-2 focus:ring-amber-200/50 text-stone-900 text-sm leading-relaxed outline-none shadow-xs resize-none"
        />
      </div>

      {/* Action Buttons: Edit, Save Note, Copy, Listen */}
      <div className="mt-4 grid grid-cols-4 gap-2">
        {/* Edit Button */}
        <button
          type="button"
          onClick={handleEditClick}
          className="flex flex-col items-center justify-center p-2.5 rounded-2xl bg-white border border-stone-200 hover:border-amber-300 active:scale-95 transition-all text-stone-700 shadow-xs cursor-pointer"
        >
          <Edit3 className="w-4 h-4 text-stone-700 mb-1" />
          <span className="text-[11px] font-semibold">Edit</span>
        </button>

        {/* Copy Button */}
        <button
          type="button"
          onClick={handleCopy}
          className={`flex flex-col items-center justify-center p-2.5 rounded-2xl border active:scale-95 transition-all shadow-xs cursor-pointer ${
            isCopied
              ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
              : 'bg-white border-stone-200 hover:border-amber-300 text-stone-700'
          }`}
        >
          {isCopied ? (
            <Check className="w-4 h-4 text-emerald-600 mb-1" />
          ) : (
            <Copy className="w-4 h-4 text-stone-700 mb-1" />
          )}
          <span className="text-[11px] font-semibold">{isCopied ? 'Copied' : 'Copy'}</span>
        </button>

        {/* Listen Button */}
        <button
          type="button"
          onClick={handleToggleListen}
          className={`flex flex-col items-center justify-center p-2.5 rounded-2xl border active:scale-95 transition-all shadow-xs cursor-pointer ${
            isListeningSpeech
              ? 'bg-purple-100 border-purple-300 text-purple-900 animate-pulse'
              : 'bg-white border-stone-200 hover:border-amber-300 text-stone-700'
          }`}
        >
          {isListeningSpeech ? (
            <VolumeX className="w-4 h-4 text-purple-700 mb-1" />
          ) : (
            <Volume2 className="w-4 h-4 text-purple-700 mb-1" />
          )}
          <span className="text-[11px] font-semibold">
            {isListeningSpeech ? 'Stop' : 'Listen'}
          </span>
        </button>

        {/* Save Note Button */}
        <button
          type="button"
          onClick={handleSave}
          className="flex flex-col items-center justify-center p-2.5 rounded-2xl bg-amber-400 hover:bg-amber-500 border border-amber-400 active:scale-95 transition-all text-stone-950 font-bold shadow-xs cursor-pointer"
        >
          <Save className="w-4 h-4 text-stone-950 mb-1" />
          <span className="text-[11px]">Save Note</span>
        </button>
      </div>

      {/* Discard & New recording prompt */}
      <div className="mt-4 text-center">
        <button
          type="button"
          onClick={onCancel}
          className="text-xs text-stone-400 hover:text-stone-600 transition-colors cursor-pointer"
        >
          Discard & Record Again
        </button>
      </div>
    </div>
  );
};
