import React from 'react';
import { SUPPORTED_LANGUAGES, Language } from '../types';
import { Check, X, Globe2 } from 'lucide-react';

interface LanguageSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedLanguage: Language;
  onSelectLanguage: (language: Language) => void;
}

export const LanguageSelectorModal: React.FC<LanguageSelectorModalProps> = ({
  isOpen,
  onClose,
  selectedLanguage,
  onSelectLanguage,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/40 backdrop-blur-xs transition-opacity">
      {/* Backdrop tap to close */}
      <div className="fixed inset-0" onClick={onClose} />

      {/* Modal / Bottom Sheet */}
      <div className="relative w-full max-w-md bg-[#FAF7F2] rounded-t-3xl sm:rounded-3xl shadow-2xl border border-amber-100/80 p-5 max-h-[85vh] flex flex-col z-10 animate-in slide-in-from-bottom duration-200">
        {/* Handle bar on mobile */}
        <div className="w-12 h-1.5 bg-stone-300 rounded-full mx-auto mb-3 sm:hidden" />

        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-amber-200/50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center text-amber-800">
              <Globe2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-stone-900">Choose Language</h3>
              <p className="text-xs text-stone-500">10 Indian languages supported</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-stone-100 hover:bg-stone-200 flex items-center justify-center text-stone-600 transition-colors"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Language List */}
        <div className="overflow-y-auto py-3 space-y-1.5 pr-1 divide-y divide-amber-100/40">
          {SUPPORTED_LANGUAGES.map((lang) => {
            const isSelected = selectedLanguage.id === lang.id;
            return (
              <button
                key={lang.id}
                type="button"
                onClick={() => {
                  onSelectLanguage(lang);
                  onClose();
                }}
                className={`w-full flex items-center justify-between p-3 rounded-2xl text-left transition-all ${
                  isSelected
                    ? 'bg-amber-100/90 border border-amber-300/80 shadow-xs'
                    : 'hover:bg-amber-50/70 border border-transparent'
                }`}
              >
                <div className="flex flex-col">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-stone-900">{lang.name}</span>
                    {lang.id === 'auto' && (
                      <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-purple-100 text-purple-700">
                        Default
                      </span>
                    )}
                  </div>
                  <span className="text-xs text-stone-500 mt-0.5 font-medium">{lang.native}</span>
                </div>

                {isSelected ? (
                  <div className="w-6 h-6 rounded-full bg-amber-600 text-white flex items-center justify-center shadow-xs">
                    <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                  </div>
                ) : (
                  <div className="w-6 h-6 rounded-full border border-stone-300" />
                )}
              </button>
            );
          })}
        </div>

        {/* Footer info */}
        <div className="pt-3 border-t border-amber-200/50 text-center">
          <p className="text-xs text-stone-500">
            Gnani Prisma v3.0 recognizes speech in real-time across Indian accents.
          </p>
        </div>
      </div>
    </div>
  );
};
