import React, { useState, useEffect, useRef } from 'react';
import { Pause, Play, Square, X, AlertCircle, Mic } from 'lucide-react';
import { Language } from '../types';
import { WaveformVisualizer } from './WaveformVisualizer';
import { getSupportedMimeType, blobToBase64 } from '../utils/audio';

interface RecordingScreenProps {
  selectedLanguage: Language;
  onFinishRecording: (audioBlob: Blob, audioBase64: string, durationSeconds: number) => void;
  onCancel: () => void;
}

export const RecordingScreen: React.FC<RecordingScreenProps> = ({
  selectedLanguage,
  onFinishRecording,
  onCancel,
}) => {
  const [seconds, setSeconds] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [recordingStatus, setRecordingStatus] = useState<string>('Requesting microphone...');
  const [micError, setMicError] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerIntervalRef = useRef<number | null>(null);
  const isStoppingRef = useRef(false);
  const startTimeRef = useRef<number>(Date.now());
  const secondsRef = useRef<number>(0);

  // Initialize Microphone & MediaRecorder
  useEffect(() => {
    let isMounted = true;

    async function initRecording() {
      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          throw new Error('Microphone access is not supported by your browser.');
        }

        const stream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
        });

        if (!isMounted) {
          stream.getTracks().forEach((track) => track.stop());
          return;
        }

        streamRef.current = stream;

        const mimeType = getSupportedMimeType();
        const mediaRecorder = new MediaRecorder(stream, { mimeType });
        mediaRecorderRef.current = mediaRecorder;
        audioChunksRef.current = [];

        mediaRecorder.ondataavailable = (event) => {
          if (event.data && event.data.size > 0) {
            audioChunksRef.current.push(event.data);
          }
        };

        mediaRecorder.onstop = async () => {
          const finalMime = mediaRecorder.mimeType || mimeType;
          const audioBlob = new Blob(audioChunksRef.current, { type: finalMime });
          const base64 = await blobToBase64(audioBlob);
          const elapsedSecs = Math.max(1, Math.round((Date.now() - startTimeRef.current) / 1000));
          const finalDuration = Math.max(elapsedSecs, secondsRef.current);

          // Clean up stream tracks
          if (streamRef.current) {
            streamRef.current.getTracks().forEach((track) => track.stop());
            streamRef.current = null;
          }

          onFinishRecording(audioBlob, base64, finalDuration);
        };

        // Start recording
        startTimeRef.current = Date.now();
        secondsRef.current = 0;
        mediaRecorder.start(250); // Slice every 250ms
        setRecordingStatus('Listening... Speak naturally');

        // Start timer - continues indefinitely until user taps Stop
        timerIntervalRef.current = window.setInterval(() => {
          setSeconds((prev) => {
            const next = prev + 1;
            secondsRef.current = next;
            return next;
          });
        }, 1000);
      } catch (err: unknown) {
        const errorMsg = err instanceof Error ? err.message : String(err);
        console.error('Microphone error:', errorMsg);
        setMicError(
          errorMsg.includes('Permission') || errorMsg.includes('NotAllowed')
            ? 'Microphone permission was denied. Please allow microphone access in your browser to record voice notes.'
            : `Could not access microphone: ${errorMsg}`
        );
        setRecordingStatus('Microphone error');
      }
    }

    initRecording();

    return () => {
      isMounted = false;
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
      }
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        try {
          mediaRecorderRef.current.stop();
        } catch {
          // ignore
        }
      }
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
      }
    };
  }, []);

  // Handle Pause / Resume
  const handleTogglePause = () => {
    if (!mediaRecorderRef.current) return;

    if (isPaused) {
      mediaRecorderRef.current.resume();
      setIsPaused(false);
      setRecordingStatus('Listening... Speak naturally');
      timerIntervalRef.current = window.setInterval(() => {
        setSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      mediaRecorderRef.current.pause();
      setIsPaused(true);
      setRecordingStatus('Recording paused');
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = null;
      }
    }
  };
  // Handle Stop Recording
  const handleStop = () => {
    if (isStoppingRef.current) return;
    isStoppingRef.current = true;

    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }

    setRecordingStatus('Saving audio & preparing transcript...');

    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch {
        // Fallback
      }
    }
  };

  const handleCancelClick = () => {
    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      // Discard by removing onstop callback before stopping
      mediaRecorderRef.current.onstop = null;
      try {
        mediaRecorderRef.current.stop();
      } catch {
        // ignore
      }
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
    }
    onCancel();
  };

  // Time format mm:ss or hh:mm:ss
  const formatTime = (totalSeconds: number) => {
    const hours = Math.floor(totalSeconds / 3600);
    const mins = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;
    if (hours > 0) {
      return `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    }
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#FAF7F2] flex flex-col justify-between p-6 max-w-md mx-auto">
      {/* Top Bar */}
      <div className="flex items-center justify-between pt-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center text-amber-800">
            <Mic className="w-4 h-4" />
          </div>
          <div>
            <span className="text-xs font-semibold text-stone-500 block uppercase tracking-wider">
              BoloNote Recording
            </span>
            <span className="text-sm font-bold text-stone-900">
              {selectedLanguage.name} ({selectedLanguage.native})
            </span>
          </div>
        </div>

        <button
          type="button"
          onClick={handleCancelClick}
          className="w-9 h-9 rounded-full bg-stone-100 hover:bg-stone-200 flex items-center justify-center text-stone-600 transition-colors"
          aria-label="Discard recording"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Main Center Content */}
      <div className="my-auto flex flex-col items-center justify-center text-center px-4">
        {micError ? (
          <div className="p-5 rounded-3xl bg-red-50 border border-red-200 text-center max-w-xs">
            <AlertCircle className="w-10 h-10 text-red-500 mx-auto mb-2" />
            <h4 className="text-sm font-bold text-red-900">Microphone Required</h4>
            <p className="text-xs text-red-700 mt-1.5 leading-relaxed">{micError}</p>
            <button
              onClick={handleCancelClick}
              className="mt-4 px-4 py-2 bg-stone-900 text-white text-xs font-semibold rounded-xl hover:bg-stone-800"
            >
              Back to Home
            </button>
          </div>
        ) : (
          <>
            {/* Elapsed Timer Display */}
            <div className="mb-2">
              <span className="text-5xl font-extrabold text-stone-900 tracking-tight font-mono tabular-nums">
                {formatTime(seconds)}
              </span>
              <span className="text-xs font-semibold text-stone-400 block mt-1">
                Recording elapsed time
              </span>
            </div>

            {/* Live recording indicator bar */}
            <div className="w-48 h-1.5 bg-amber-100 rounded-full overflow-hidden my-3">
              <div
                className={`h-full w-full rounded-full transition-all duration-300 ${
                  isPaused ? 'bg-amber-300' : 'bg-gradient-to-r from-amber-400 via-purple-400 to-amber-400 animate-pulse'
                }`}
              />
            </div>

            {/* Animated Audio Waveform */}
            <div className="w-full my-4">
              <WaveformVisualizer
                stream={streamRef.current}
                isRecording={!isPaused && !micError}
                isPaused={isPaused}
              />
            </div>

            {/* Clear Status Message */}
            <div className="mt-2 inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white border border-amber-200/80 shadow-xs">
              <span
                className={`w-2.5 h-2.5 rounded-full ${
                  isPaused
                    ? 'bg-amber-400'
                    : 'bg-purple-600 animate-pulse'
                }`}
              />
              <span className="text-xs font-semibold text-stone-700">{recordingStatus}</span>
            </div>
          </>
        )}
      </div>

      {/* Controls Toolbar */}
      {!micError && (
        <div className="pb-6">
          <div className="flex items-center justify-center gap-5">
            {/* Pause / Resume button */}
            <button
              type="button"
              onClick={handleTogglePause}
              className="w-14 h-14 rounded-full bg-white border border-stone-200 hover:border-amber-300 flex items-center justify-center text-stone-800 shadow-sm active:scale-95 transition-all"
              aria-label={isPaused ? 'Resume recording' : 'Pause recording'}
            >
              {isPaused ? (
                <Play className="w-5 h-5 fill-current ml-0.5 text-amber-600" />
              ) : (
                <Pause className="w-5 h-5 text-stone-700" />
              )}
            </button>

            {/* Primary Stop & Finish Button */}
            <button
              type="button"
              onClick={handleStop}
              className="px-8 h-14 rounded-full bg-gradient-to-r from-amber-300 via-amber-200 to-purple-300 hover:from-amber-400 hover:to-purple-400 text-stone-900 font-bold text-sm flex items-center gap-2.5 shadow-md active:scale-95 transition-all border border-amber-300 cursor-pointer"
            >
              <div className="w-5 h-5 rounded-md bg-stone-900 flex items-center justify-center">
                <Square className="w-2.5 h-2.5 fill-white text-white" />
              </div>
              <span>Stop & Save Note</span>
            </button>

            {/* Discard Button */}
            <button
              type="button"
              onClick={handleCancelClick}
              className="w-14 h-14 rounded-full bg-stone-100 hover:bg-red-50 hover:text-red-600 flex items-center justify-center text-stone-500 transition-colors active:scale-95"
              aria-label="Discard recording"
              title="Discard"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <p className="text-[11px] text-center text-stone-400 mt-4">
            Tap 'Stop & Save Note' anytime to generate your transcript
          </p>
        </div>
      )}
    </div>
  );
};
