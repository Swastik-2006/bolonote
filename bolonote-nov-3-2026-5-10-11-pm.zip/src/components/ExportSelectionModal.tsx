import React, { useState, useMemo, useEffect } from 'react';
import {
  X,
  Check,
  FileText,
  FileCode,
  Loader2,
  Search,
  Download,
  AlertCircle,
} from 'lucide-react';
import { Note } from '../types';

interface ExportSelectionModalProps {
  isOpen: boolean;
  format: 'pdf' | 'txt';
  notes: Note[];
  onClose: () => void;
  onExport: (selectedNotes: Note[], format: 'pdf' | 'txt') => Promise<{ success: boolean; message?: string }>;
}

export const ExportSelectionModal: React.FC<ExportSelectionModalProps> = ({
  isOpen,
  format: initialFormat,
  notes,
  onClose,
  onExport,
}) => {
  const [currentFormat, setCurrentFormat] = useState<'pdf' | 'txt'>(initialFormat);
  // Initialize with all notes selected by default so users can quickly export all or customize
  const [selectedIds, setSelectedIds] = useState<Set<string>>(() => new Set(notes.map((n) => n.id)));
  const [searchQuery, setSearchQuery] = useState('');
  const [isExporting, setIsExporting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Sync selection and format whenever modal opens
  useEffect(() => {
    if (isOpen) {
      setCurrentFormat(initialFormat);
      setSelectedIds(new Set(notes.map((n) => n.id)));
      setSearchQuery('');
      setErrorMessage(null);
      setIsExporting(false);
    }
  }, [isOpen, initialFormat, notes]);

  // Filter notes based on search query
  const filteredNotes = useMemo(() => {
    if (!searchQuery.trim()) return notes;
    const q = searchQuery.toLowerCase();
    return notes.filter(
      (n) =>
        (n.title && n.title.toLowerCase().includes(q)) ||
        (n.transcript && n.transcript.toLowerCase().includes(q)) ||
        (n.language && n.language.toLowerCase().includes(q))
    );
  }, [notes, searchQuery]);

  if (!isOpen) return null;

  const totalCount = notes.length;
  const selectedCount = selectedIds.size;
  const isAllSelected = totalCount > 0 && selectedCount === totalCount;
  const isNoneSelected = selectedCount === 0;

  const handleToggleNote = (id: string) => {
    setErrorMessage(null);
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleSelectAll = () => {
    setErrorMessage(null);
    setSelectedIds(new Set(notes.map((n) => n.id)));
  };

  const handleDeselectAll = () => {
    setErrorMessage(null);
    setSelectedIds(new Set());
  };

  const handleConfirmExport = async () => {
    if (selectedCount === 0) {
      setErrorMessage('Please select at least one note to export.');
      return;
    }

    const selectedNotes = notes.filter((n) => selectedIds.has(n.id));
    setIsExporting(true);
    setErrorMessage(null);

    try {
      const result = await onExport(selectedNotes, currentFormat);
      if (result.success) {
        onClose();
      } else if (result.message) {
        setErrorMessage(result.message);
      }
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Export failed. Please try again.');
    } finally {
      setIsExporting(false);
    }
  };

  const formatDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return dateStr;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-150">
      {/* Backdrop */}
      <div className="fixed inset-0" onClick={isExporting ? undefined : onClose} />

      {/* Modal Dialog Card */}
      <div className="relative w-full max-w-md bg-[#FAF7F2] rounded-t-3xl sm:rounded-3xl shadow-2xl border border-stone-200/80 p-5 max-h-[90vh] flex flex-col z-10 animate-in slide-in-from-bottom duration-200">
        {/* Mobile drag handle */}
        <div className="w-12 h-1.5 bg-stone-300 rounded-full mx-auto mb-3 sm:hidden" />

        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-amber-200/60">
          <div className="flex items-center gap-2.5">
            <div
              className={`w-9 h-9 rounded-2xl flex items-center justify-center transition-colors ${
                currentFormat === 'pdf'
                  ? 'bg-purple-100 text-purple-800'
                  : 'bg-amber-100 text-amber-800'
              }`}
            >
              {currentFormat === 'pdf' ? (
                <FileText className="w-5 h-5" />
              ) : (
                <FileCode className="w-5 h-5" />
              )}
            </div>
            <div>
              <h2 className="text-base font-bold text-stone-900 leading-tight">
                Export Notes as {currentFormat.toUpperCase()}
              </h2>
              <p className="text-[11px] text-stone-500 font-medium">
                Select individual notes to include in your export
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            disabled={isExporting}
            className="w-8 h-8 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-500 hover:text-stone-800 flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Format Selector Pills (Allow switching between PDF and TXT) */}
        <div className="pt-3 pb-1">
          <div className="grid grid-cols-2 p-1 bg-stone-200/60 rounded-2xl gap-1">
            <button
              type="button"
              disabled={isExporting}
              onClick={() => {
                setErrorMessage(null);
                setCurrentFormat('pdf');
              }}
              className={`py-1.5 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                currentFormat === 'pdf'
                  ? 'bg-white text-purple-900 shadow-xs ring-1 ring-stone-200'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>PDF Document</span>
            </button>
            <button
              type="button"
              disabled={isExporting}
              onClick={() => {
                setErrorMessage(null);
                setCurrentFormat('txt');
              }}
              className={`py-1.5 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                currentFormat === 'txt'
                  ? 'bg-white text-amber-900 shadow-xs ring-1 ring-stone-200'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>Plain Text (.txt)</span>
            </button>
          </div>
        </div>

        {/* Selection Toolbar & Count */}
        <div className="pt-2 pb-2 space-y-2">
          <div className="flex items-center justify-between gap-2">
            {/* Selected Count Indicator */}
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-stone-900 bg-amber-100/70 text-amber-950 px-2.5 py-0.5 rounded-full border border-amber-200/60">
                {selectedCount} {selectedCount === 1 ? 'note' : 'notes'} selected
              </span>
              <span className="text-[11px] text-stone-400 font-medium">of {totalCount} total</span>
            </div>

            {/* Select All / Deselect All Action Buttons */}
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={handleSelectAll}
                disabled={isAllSelected || totalCount === 0 || isExporting}
                className="px-2.5 py-1 rounded-xl text-[11px] font-bold text-stone-700 bg-white border border-stone-200 hover:bg-stone-50 active:scale-95 disabled:opacity-40 disabled:pointer-events-none transition-all cursor-pointer"
              >
                Select All
              </button>
              <button
                type="button"
                onClick={handleDeselectAll}
                disabled={isNoneSelected || isExporting}
                className="px-2.5 py-1 rounded-xl text-[11px] font-bold text-stone-700 bg-white border border-stone-200 hover:bg-stone-50 active:scale-95 disabled:opacity-40 disabled:pointer-events-none transition-all cursor-pointer"
              >
                Deselect All
              </button>
            </div>
          </div>

          {/* Search bar when there are several notes */}
          {totalCount > 3 && (
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search notes to select..."
                className="w-full pl-8 pr-7 py-1.5 rounded-xl bg-white border border-stone-200 text-stone-900 text-xs font-medium outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-200"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          )}
        </div>

        {/* Error notice if triggered */}
        {errorMessage && (
          <div className="mb-2 p-2.5 rounded-xl bg-red-50 border border-red-200 text-red-800 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
            <span className="flex-1 font-medium">{errorMessage}</span>
          </div>
        )}

        {/* Scrollable Notes List */}
        <div className="flex-1 overflow-y-auto py-1 pr-0.5 space-y-2 min-h-[160px] max-h-[46vh]">
          {totalCount === 0 ? (
            <div className="py-12 text-center">
              <p className="text-sm font-semibold text-stone-700">No saved notes found</p>
              <p className="text-xs text-stone-400 mt-1">Record a voice note first to export.</p>
            </div>
          ) : filteredNotes.length === 0 ? (
            <div className="py-8 text-center text-xs text-stone-400">
              No notes match "{searchQuery}"
            </div>
          ) : (
            filteredNotes.map((note) => {
              const isSelected = selectedIds.has(note.id);

              return (
                <div
                  key={note.id}
                  onClick={() => !isExporting && handleToggleNote(note.id)}
                  className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 select-none ${
                    isSelected
                      ? 'bg-white border-purple-300 shadow-xs ring-1 ring-purple-100'
                      : 'bg-stone-50/70 border-stone-200 hover:bg-white hover:border-stone-300'
                  }`}
                >
                  {/* Custom Checkbox */}
                  <div className="pt-0.5 shrink-0">
                    <div
                      className={`w-5 h-5 rounded-lg flex items-center justify-center transition-colors ${
                        isSelected
                          ? 'bg-purple-700 text-white'
                          : 'border-2 border-stone-300 bg-white hover:border-stone-400'
                      }`}
                    >
                      {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                    </div>
                  </div>

                  {/* Note Details */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1.5">
                      <h4
                        className={`text-xs font-bold truncate ${
                          isSelected ? 'text-stone-900' : 'text-stone-700'
                        }`}
                      >
                        {note.title || 'Untitled Note'}
                      </h4>
                      <span className="text-[10px] font-semibold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-full shrink-0">
                        {note.language}
                      </span>
                    </div>

                    {/* Excerpt */}
                    <p className="text-[11px] text-stone-500 mt-1 line-clamp-1 leading-normal font-sans">
                      {note.transcript || '(Empty note)'}
                    </p>

                    {/* Metadata: Date and Duration */}
                    <div className="flex items-center gap-2 mt-1.5 text-[10px] text-stone-400 font-medium">
                      <span>{formatDate(note.createdAt)}</span>
                      <span>·</span>
                      <span>{note.durationSeconds}s audio</span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Modal Actions Footer */}
        <div className="pt-3 mt-2 border-t border-amber-200/60 flex items-center justify-between gap-2.5">
          <button
            type="button"
            onClick={onClose}
            disabled={isExporting}
            className="px-4 py-2.5 rounded-2xl bg-white border border-stone-200 hover:bg-stone-50 text-stone-700 text-xs font-bold transition-colors cursor-pointer"
          >
            Cancel
          </button>

          <button
            type="button"
            onClick={handleConfirmExport}
            disabled={isNoneSelected || isExporting}
            className={`flex-1 py-2.5 px-4 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer ${
              isNoneSelected
                ? 'bg-stone-200 text-stone-400 cursor-not-allowed'
                : currentFormat === 'pdf'
                ? 'bg-purple-700 hover:bg-purple-800 text-white active:scale-[0.98]'
                : 'bg-amber-400 hover:bg-amber-500 text-stone-950 active:scale-[0.98]'
            }`}
          >
            {isExporting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Generating {currentFormat.toUpperCase()}...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Export Selected Notes</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
