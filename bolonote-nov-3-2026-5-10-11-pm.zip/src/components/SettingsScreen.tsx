import React, { useState, useEffect } from 'react';
import {
  Globe2,
  HardDrive,
  FileText,
  FileCode,
  Trash2,
  ChevronRight,
} from 'lucide-react';
import { Language, Note } from '../types';
import { getStorageUsage, clearAllStoredNotes, getStoredNotes } from '../utils/storage';
import { exportNotesAsPdf, exportNotesAsTxt } from '../utils/export';
import { ExportSelectionModal } from './ExportSelectionModal';

interface SettingsScreenProps {
  defaultLanguage: Language;
  onSelectDefaultLanguage: (lang: Language) => void;
  onOpenLanguageSelector: () => void;
  onNotesCleared: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  defaultLanguage,
  onOpenLanguageSelector,
  onNotesCleared,
}) => {
  const [storageInfo, setStorageInfo] = useState<{ noteCount: number; kbUsed: string }>({
    noteCount: 0,
    kbUsed: '0',
  });
  const [exportNotice, setExportNotice] = useState<string | null>(null);
  const [exportModal, setExportModal] = useState<{
    isOpen: boolean;
    format: 'pdf' | 'txt';
  }>({
    isOpen: false,
    format: 'pdf',
  });

  const [availableNotes, setAvailableNotes] = useState<Note[]>([]);

  useEffect(() => {
    setStorageInfo(getStorageUsage());
    setAvailableNotes(getStoredNotes());
  }, []);

  const handleOpenExport = (format: 'pdf' | 'txt') => {
    setExportNotice(null);
    const notes = getStoredNotes();
    setAvailableNotes(notes);
    if (!notes || notes.length === 0) {
      setExportNotice('No saved voice notes available to export. Record a note first.');
      return;
    }
    setExportModal({ isOpen: true, format });
  };

  const handleExportSelected = async (selectedNotes: Note[], format: 'pdf' | 'txt') => {
    if (format === 'pdf') {
      const res = await exportNotesAsPdf(selectedNotes);
      if (!res.success && res.message) {
        return res;
      }
      setExportNotice(`Successfully exported ${selectedNotes.length} ${selectedNotes.length === 1 ? 'note' : 'notes'} as PDF.`);
      return { success: true };
    } else {
      const res = await exportNotesAsTxt(selectedNotes);
      if (!res.success && res.message) {
        return res;
      }
      setExportNotice(`Successfully exported ${selectedNotes.length} ${selectedNotes.length === 1 ? 'note' : 'notes'} as TXT.`);
      return { success: true };
    }
  };

  const handleClearAll = () => {
    if (window.confirm('Are you sure you want to delete all saved voice notes? This cannot be undone.')) {
      clearAllStoredNotes();
      setStorageInfo({ noteCount: 0, kbUsed: '0' });
      onNotesCleared();
    }
  };

  return (
    <div className="flex flex-col min-h-screen pb-24 px-4 max-w-md mx-auto">
      {/* Top Header */}
      <div className="pt-6 pb-4">
        <h1 className="text-xl font-bold tracking-tight text-stone-900">Settings</h1>
        <p className="text-xs text-stone-500 font-medium">Preferences & Storage</p>
      </div>

      <div className="space-y-4">
        {/* Language Preference */}
        <section className="p-4 rounded-3xl bg-white border border-stone-200/80 shadow-xs">
          <div className="flex items-center gap-2 mb-3">
            <Globe2 className="w-4 h-4 text-purple-700" />
            <h2 className="text-xs font-bold text-stone-900 uppercase tracking-wider">
              Language Settings
            </h2>
          </div>

          <button
            type="button"
            onClick={onOpenLanguageSelector}
            className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-amber-50/70 border border-amber-200/80 hover:bg-amber-100/60 transition-all text-left cursor-pointer"
          >
            <div>
              <p className="text-[11px] font-medium text-stone-500">Default Recording Language</p>
              <p className="text-sm font-bold text-stone-900">
                {defaultLanguage.name} ({defaultLanguage.native})
              </p>
            </div>
            <div className="flex items-center gap-1 text-xs font-semibold text-purple-700">
              <span>Change</span>
              <ChevronRight className="w-4 h-4" />
            </div>
          </button>

          <p className="text-[11px] text-stone-400 mt-2">
            Auto Detect recognizes whether you are speaking English, Hindi, Bengali, Marathi, Gujarati, Punjabi, Kannada, Telugu, Tamil, or Malayalam.
          </p>
        </section>

        {/* Local Storage & Export Options */}
        <section className="p-4 rounded-3xl bg-white border border-stone-200/80 shadow-xs">
          <div className="flex items-center gap-2 mb-3">
            <HardDrive className="w-4 h-4 text-stone-600" />
            <h2 className="text-xs font-bold text-stone-900 uppercase tracking-wider">
              Notes Storage & Export
            </h2>
          </div>

          <div className="grid grid-cols-2 gap-2 mb-3">
            <div className="p-3 rounded-2xl bg-stone-50 border border-stone-200/70">
              <span className="text-[10px] uppercase font-bold text-stone-400 block">Total Notes</span>
              <span className="text-lg font-bold text-stone-900">{storageInfo.noteCount}</span>
            </div>
            <div className="p-3 rounded-2xl bg-stone-50 border border-stone-200/70">
              <span className="text-[10px] uppercase font-bold text-stone-400 block">Storage Used</span>
              <span className="text-lg font-bold text-stone-900">{storageInfo.kbUsed} KB</span>
            </div>
          </div>

          {exportNotice && (
            <div className="mb-3 p-3 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-800 font-medium">
              {exportNotice}
            </div>
          )}

          <div className="space-y-2">
            {/* Export as PDF */}
            <button
              type="button"
              onClick={() => handleOpenExport('pdf')}
              className="w-full py-2.5 px-3 rounded-2xl bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5 text-purple-700" />
              <span>Export Notes as PDF</span>
            </button>

            {/* Export as TXT */}
            <button
              type="button"
              onClick={() => handleOpenExport('txt')}
              className="w-full py-2.5 px-3 rounded-2xl bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <FileCode className="w-3.5 h-3.5 text-amber-700" />
              <span>Export Notes as TXT</span>
            </button>

            {/* Clear All Notes */}
            <button
              type="button"
              onClick={handleClearAll}
              className="w-full py-2.5 px-3 rounded-2xl bg-red-50 hover:bg-red-100 text-red-700 text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer mt-2"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear All Saved Notes</span>
            </button>
          </div>

          <p className="text-[11px] text-stone-400 mt-2 text-center">
            Your voice notes and recordings remain strictly in your browser.
          </p>
        </section>

        {/* About App */}
        <section className="p-4 rounded-3xl bg-amber-100/40 border border-amber-200/60 text-center">
          <p className="text-xs font-bold text-stone-800">BoloNote</p>
          <p className="text-[11px] text-stone-500 mt-0.5">
            "Speak naturally. Your words become notes."
          </p>
          <p className="text-[10px] text-stone-400 mt-1">
            Multilingual Voice Notes for India
          </p>
        </section>
      </div>

      {/* Note Selection Modal for Exporting */}
      <ExportSelectionModal
        isOpen={exportModal.isOpen}
        format={exportModal.format}
        notes={availableNotes}
        onClose={() => setExportModal((prev) => ({ ...prev, isOpen: false }))}
        onExport={handleExportSelected}
      />
    </div>
  );
};
