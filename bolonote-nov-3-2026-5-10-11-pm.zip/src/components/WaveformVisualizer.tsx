import React, { useEffect, useRef } from 'react';

interface WaveformVisualizerProps {
  stream: MediaStream | null;
  isRecording: boolean;
  isPaused: boolean;
  height?: number;
}

export const WaveformVisualizer: React.FC<WaveformVisualizerProps> = ({
  stream,
  isRecording,
  isPaused,
  height = 90,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const dataArrayRef = useRef<Uint8Array | null>(null);

  useEffect(() => {
    if (!stream || !isRecording) {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      return;
    }

    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const audioCtx = new AudioCtx();
      audioContextRef.current = audioCtx;

      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 64; // Gives 32 frequency bins, ideal for aesthetic bars
      analyser.smoothingTimeConstant = 0.8;
      analyserRef.current = analyser;

      const source = audioCtx.createMediaStreamSource(stream);
      source.connect(analyser);

      const bufferLength = analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);
      dataArrayRef.current = dataArray;

      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const render = () => {
        animationFrameRef.current = requestAnimationFrame(render);

        const width = canvas.width;
        const canvasHeight = canvas.height;

        ctx.clearRect(0, 0, width, canvasHeight);

        if (isPaused) {
          // Draw gentle static paused wave
          ctx.beginPath();
          ctx.strokeStyle = '#DDD6FE';
          ctx.lineWidth = 3;
          ctx.lineCap = 'round';
          const midY = canvasHeight / 2;
          for (let x = 0; x < width; x += 6) {
            const y = midY + Math.sin(x * 0.05) * 4;
            if (x === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          }
          ctx.stroke();
          return;
        }

        analyser.getByteFrequencyData(dataArray);

        // Number of bars to render
        const barCount = 28;
        const totalSpacing = 4;
        const barWidth = Math.max(3, (width - (barCount - 1) * totalSpacing) / barCount);

        for (let i = 0; i < barCount; i++) {
          // Sample frequency data
          const dataIndex = Math.floor((i / barCount) * bufferLength);
          const rawValue = dataArray[dataIndex] || 0;
          // Scale bar height smoothly (min height 4px, max height 80%)
          const percent = Math.min(1, Math.max(0.08, rawValue / 240));
          const barHeight = percent * (canvasHeight - 12);

          const x = i * (barWidth + totalSpacing);
          const y = (canvasHeight - barHeight) / 2;

          // Gradient from warm pastel yellow to soft lavender
          const gradient = ctx.createLinearGradient(0, y, 0, y + barHeight);
          gradient.addColorStop(0, '#A78BFA'); // lavender
          gradient.addColorStop(0.5, '#FBBF24'); // warm pastel yellow
          gradient.addColorStop(1, '#C084FC'); // soft purple

          ctx.fillStyle = gradient;
          ctx.beginPath();
          ctx.roundRect(x, y, barWidth, barHeight, [4, 4, 4, 4]);
          ctx.fill();
        }
      };

      render();
    } catch (err) {
      console.warn('Audio visualization context not available', err);
    }

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close().catch(() => {});
      }
    };
  }, [stream, isRecording, isPaused]);

  // Fallback idle wave if no stream
  useEffect(() => {
    if (stream && isRecording) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let frame = 0;
    const drawIdle = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const width = canvas.width;
      const midY = canvas.height / 2;

      ctx.beginPath();
      ctx.strokeStyle = '#E2E8F0';
      ctx.lineWidth = 2.5;
      ctx.lineCap = 'round';

      for (let x = 0; x < width; x += 4) {
        const y = midY + Math.sin(x * 0.04 + frame * 0.03) * 6;
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      frame++;
      animationFrameRef.current = requestAnimationFrame(drawIdle);
    };

    drawIdle();

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [stream, isRecording]);

  return (
    <div className="w-full flex items-center justify-center py-2 px-3">
      <canvas
        ref={canvasRef}
        width={320}
        height={height}
        className="w-full max-w-xs h-[90px] rounded-2xl bg-amber-50/50"
      />
    </div>
  );
};
