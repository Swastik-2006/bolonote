import React, { useState, useEffect } from 'react';
import {
  AppScreen,
  Language,
  Note,
  SUPPORTED_LANGUAGES,
} from './types';
import { getStoredNotes, saveStoredNote, deleteStoredNote } from './utils/storage';
import { transcribeWithGnaniServer } from './utils/audio';

import { HomeScreen } from './components/HomeScreen';
import { RecordingScreen } from './components/RecordingScreen';
import { TranscriptScreen } from './components/TranscriptScreen';
import { MyNotesScreen } from './components/MyNotesScreen';
import { SettingsScreen } from './components/SettingsScreen';
import { BottomNav } from './components/BottomNav';
import { LanguageSelectorModal } from './components/LanguageSelectorModal';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<AppScreen>('home');
  const [selectedLanguage, setSelectedLanguage] = useState<Language>(SUPPORTED_LANGUAGES[0]); // Auto Detect
  const [isLanguageModalOpen, setIsLanguageModalOpen] = useState(false);
  const [notes, setNotes] = useState<Note[]>([]);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Active recording & transcript state
  const [currentAudioBase64, setCurrentAudioBase64] = useState<string | undefined>();
  const [currentDurationSeconds, setCurrentDurationSeconds] = useState<number>(0);
  const [currentTranscript, setCurrentTranscript] = useState<string>('');
  const [currentNoteTitle, setCurrentNoteTitle] = useState<string>('');
  const [detectedLanguageName, setDetectedLanguageName] = useState<string | undefined>();
  const [serverTranscriptionStatus, setServerTranscriptionStatus] = useState<{
    configured: boolean;
    success: boolean;
    message?: string;
  }>({
    configured: false,
    success: false,
  });

  const [isTranscribing, setIsTranscribing] = useState(false);

  // Load notes on mount
  useEffect(() => {
    const loadedNotes = getStoredNotes();
    setNotes(loadedNotes);
  }, []);

  // Toast helper
  const showToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  };

  // Start recording
  const handleStartRecording = () => {
    setCurrentScreen('recording');
  };

  // Cancel recording
  const handleCancelRecording = () => {
    setCurrentScreen('home');
  };

  // Finish recording
  const handleFinishRecording = async (
    audioBlob: Blob,
    audioBase64: string,
    durationSeconds: number
  ) => {
    setCurrentAudioBase64(audioBase64);
    setCurrentDurationSeconds(durationSeconds);

    const now = new Date();
    const defaultTitle = `Voice Note - ${now.toLocaleDateString('en-IN', {
      month: 'short',
      day: 'numeric',
    })}, ${now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}`;
    setCurrentNoteTitle(defaultTitle);
    setCurrentTranscript('');
    setDetectedLanguageName(selectedLanguage.name);
    setIsTranscribing(true);

    // Navigate to transcript screen
    setCurrentScreen('transcript');

    // Call server-side Gnani Prisma v3.0 integration point
    try {
      const result = await transcribeWithGnaniServer(
        audioBase64,
        audioBlob.type || 'audio/webm',
        selectedLanguage.code
      );

      setServerTranscriptionStatus({
        configured: Boolean(result.configured),
        success: Boolean(result.success),
        message: result.message,
      });

      if (result.success) {
        if (result.transcript && result.transcript.trim()) {
          setCurrentTranscript(result.transcript.trim());
          showToast('Transcribed with Gnani Prisma v3.0');
        } else {
          showToast('Audio processed. No speech detected.');
        }

        if (result.detectedLanguage) {
          const matchLang = SUPPORTED_LANGUAGES.find(
            (l) => l.code === result.detectedLanguage || l.gnaniLang === result.detectedLanguage
          );
          if (matchLang) {
            setDetectedLanguageName(matchLang.name);
          }
        }
      } else if (result.message) {
        showToast(`Gnani: ${result.message.slice(0, 40)}`);
      }
    } catch (err) {
      console.warn('Transcription request error:', err);
      setServerTranscriptionStatus({
        configured: true,
        success: false,
        message: 'Could not connect to transcription server.',
      });
    } finally {
      setIsTranscribing(false);
    }
  };

  // Save note from Transcript screen
  const handleSaveNote = (noteData: Omit<Note, 'id' | 'createdAt'>) => {
    const newNote: Note = {
      ...noteData,
      id: `note-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      createdAt: new Date().toISOString(),
    };

    const updated = saveStoredNote(newNote);
    setNotes(updated);
    showToast('Note saved to My Notes!');
    setCurrentScreen('my-notes');
  };

  // Update existing note
  const handleUpdateNote = (updatedNote: Note) => {
    const updated = saveStoredNote(updatedNote);
    setNotes(updated);
    showToast('Note updated!');
  };

  // Delete note
  const handleDeleteNote = (id: string) => {
    const updated = deleteStoredNote(id);
    setNotes(updated);
    showToast('Note deleted');
  };

  // Select note from Home recent notes to view
  const handleSelectNoteFromHome = (_note: Note) => {
    setCurrentScreen('my-notes');
  };

  return (
    <div className="min-h-screen bg-[#FAF7F2] text-stone-900 selection:bg-amber-200 selection:text-stone-900 font-sans">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-2xl bg-stone-900 text-white text-xs font-semibold shadow-xl border border-stone-800 animate-in fade-in slide-in-from-top duration-200">
          {toastMessage}
        </div>
      )}

      {/* Screen Views */}
      <main className="w-full">
        {currentScreen === 'home' && (
          <HomeScreen
            selectedLanguage={selectedLanguage}
            onOpenLanguageSelector={() => setIsLanguageModalOpen(true)}
            onStartRecording={handleStartRecording}
            recentNotes={notes}
            onSelectNote={handleSelectNoteFromHome}
            onViewAllNotes={() => setCurrentScreen('my-notes')}
          />
        )}

        {currentScreen === 'recording' && (
          <RecordingScreen
            selectedLanguage={selectedLanguage}
            onFinishRecording={handleFinishRecording}
            onCancel={handleCancelRecording}
          />
        )}

        {currentScreen === 'transcript' && (
          <TranscriptScreen
            initialTitle={currentNoteTitle}
            initialTranscript={currentTranscript}
            selectedLanguage={selectedLanguage}
            detectedLanguageName={detectedLanguageName}
            audioBase64={currentAudioBase64}
            durationSeconds={currentDurationSeconds}
            isTranscribing={isTranscribing}
            serverTranscriptionStatus={serverTranscriptionStatus}
            onSaveNote={handleSaveNote}
            onCancel={() => setCurrentScreen('home')}
          />
        )}

        {currentScreen === 'my-notes' && (
          <MyNotesScreen
            notes={notes}
            onUpdateNote={handleUpdateNote}
            onDeleteNote={handleDeleteNote}
            onNavigateToRecord={handleStartRecording}
          />
        )}

        {currentScreen === 'settings' && (
          <SettingsScreen
            defaultLanguage={selectedLanguage}
            onSelectDefaultLanguage={setSelectedLanguage}
            onOpenLanguageSelector={() => setIsLanguageModalOpen(true)}
            onNotesCleared={() => setNotes([])}
          />
        )}
      </main>

      {/* Language Selector Modal */}
      <LanguageSelectorModal
        isOpen={isLanguageModalOpen}
        onClose={() => setIsLanguageModalOpen(false)}
        selectedLanguage={selectedLanguage}
        onSelectLanguage={(lang) => {
          setSelectedLanguage(lang);
          showToast(`Language set to ${lang.name}`);
        }}
      />

      {/* Fixed Bottom Navigation (visible on Home, My Notes, Settings) */}
      {currentScreen !== 'recording' && currentScreen !== 'transcript' && (
        <BottomNav
          currentScreen={currentScreen}
          onNavigate={(screen) => setCurrentScreen(screen)}
          noteCount={notes.length}
        />
      )}
    </div>
  );
}
