export interface Language {
  id: string;
  name: string;
  native: string;
  code: string;
  gnaniLang?: string;
}

export interface Note {
  id: string;
  title: string;
  transcript: string;
  language: string;
  languageCode: string;
  createdAt: string;
  durationSeconds: number;
  audioBase64?: string;
  isStarred?: boolean;
}

export type AppScreen = 'home' | 'recording' | 'transcript' | 'my-notes' | 'settings';

export type RecordingState = 'idle' | 'recording' | 'paused' | 'processing' | 'completed';

export interface GnaniStatus {
  sttProvider: string;
  ttsProvider: string;
  sttConfigured: boolean;
  ttsConfigured: boolean;
  requiresAccessKey: boolean;
  maxRecordingDurationSeconds?: number;
  supportedLanguages: Language[];
  integrationReady: boolean;
  keyDetected?: boolean;
  connectionStatus?: 'Connected' | 'Not connected' | 'Not tested';
  testMessage?: string;
  testedAt?: string;
}

export const SUPPORTED_LANGUAGES: Language[] = [
  { id: 'auto', name: 'Auto Detect', native: 'स्वतः पहचानें', code: 'auto' },
  { id: 'en', name: 'English', native: 'English', code: 'en-IN', gnaniLang: 'en' },
  { id: 'hi', name: 'Hindi', native: 'हिन्दी', code: 'hi-IN', gnaniLang: 'hi' },
  { id: 'bn', name: 'Bengali', native: 'বাংলা', code: 'bn-IN', gnaniLang: 'bn' },
  { id: 'mr', name: 'Marathi', native: 'मराठी', code: 'mr-IN', gnaniLang: 'mr' },
  { id: 'gu', name: 'Gujarati', native: 'ગુજરાતી', code: 'gu-IN', gnaniLang: 'gu' },
  { id: 'pa', name: 'Punjabi', native: 'ਪੰਜਾਬੀ', code: 'pa-IN', gnaniLang: 'pa' },
  { id: 'kn', name: 'Kannada', native: 'ಕನ್ನಡ', code: 'kn-IN', gnaniLang: 'kn' },
  { id: 'te', name: 'Telugu', native: 'తెలుగు', code: 'te-IN', gnaniLang: 'te' },
  { id: 'ta', name: 'Tamil', native: 'தமிழ்', code: 'ta-IN', gnaniLang: 'ta' },
  { id: 'ml', name: 'Malayalam', native: 'മലയാളം', code: 'ml-IN', gnaniLang: 'ml' },
];
