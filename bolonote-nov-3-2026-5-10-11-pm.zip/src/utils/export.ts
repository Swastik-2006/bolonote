import { Note } from '../types';

/**
 * Export saved voice notes as formatted Plain Text (.txt)
 * Preserves full UTF-8 Unicode encoding with BOM to prevent mojibake across all readers.
 */
export async function exportNotesAsTxt(notes: Note[]): Promise<{ success: boolean; message?: string }> {
  if (!notes || notes.length === 0) {
    return { success: false, message: 'No notes available to export. Record or create a note first.' };
  }

  const exportDate = new Date().toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  let text = '';
  text += '============================================================\n';
  text += 'BOLONOTE - SAVED VOICE NOTES\n';
  text += `Exported: ${exportDate}\n`;
  text += `Total Notes: ${notes.length}\n`;
  text += '============================================================\n\n';

  notes.forEach((note, index) => {
    const formattedDate = new Date(note.createdAt).toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

    text += `[Note ${index + 1}] ${note.title || 'Untitled Note'}\n`;
    text += `Date: ${formattedDate}\n`;
    text += `Language: ${note.language} (${note.languageCode})\n`;
    text += `Duration: ${note.durationSeconds}s\n`;
    text += '------------------------------------------------------------\n';
    text += `${note.transcript || '(No transcript content)'}\n\n`;
    text += '============================================================\n\n';
  });

  // Prepend UTF-8 BOM (\uFEFF) to guarantee correct Unicode decoding across all desktop and mobile apps
  const blob = new Blob(['\uFEFF' + text], { type: 'text/plain;charset=utf-8' });
  const filename = `bolonote-notes-${new Date().toISOString().slice(0, 10)}.txt`;

  // Mobile Web Share API support if available
  if (typeof navigator !== 'undefined' && navigator.share && navigator.canShare) {
    try {
      const file = new File([blob], filename, { type: 'text/plain;charset=utf-8' });
      if (navigator.canShare({ files: [file] })) {
        await navigator.share({
          files: [file],
          title: 'BoloNote Voice Notes',
          text: `Export of ${notes.length} voice notes from BoloNote.`,
        });
        return { success: true };
      }
    } catch {
      // User cancelled share or fallback to anchor download
    }
  }

  // Standard download fallback
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 1000);

  return { success: true };
}

/**
 * Export saved voice notes as a high-fidelity multilingual PDF (.pdf)
 * Uses server-side Pango, Cairo, and HarfBuzz with embedded Noto fonts for all
 * 10 supported Indian scripts, preserving conjunct characters and vowel marks.
 */
export async function exportNotesAsPdf(notes: Note[]): Promise<{ success: boolean; message?: string }> {
  if (!notes || notes.length === 0) {
    return { success: false, message: 'No notes available to export. Record or create a note first.' };
  }

  try {
    const filename = `bolonote-notes-${new Date().toISOString().slice(0, 10)}.pdf`;

    // Request high-fidelity vector PDF from backend generator
    const response = await fetch('/api/export-pdf', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ notes }),
    });

    if (!response.ok) {
      const errJson = await response.json().catch(() => ({}));
      throw new Error(errJson.message || `Server returned HTTP ${response.status}`);
    }

    const pdfBlob = await response.blob();

    // Check Mobile Web Share API support with PDF file
    if (typeof navigator !== 'undefined' && navigator.share && navigator.canShare) {
      try {
        const file = new File([pdfBlob], filename, { type: 'application/pdf' });
        if (navigator.canShare({ files: [file] })) {
          await navigator.share({
            files: [file],
            title: 'BoloNote PDF Notes',
            text: `Export of ${notes.length} voice notes from BoloNote.`,
          });
          return { success: true };
        }
      } catch {
        // Fallback to direct download
      }
    }

    // Direct download
    const url = URL.createObjectURL(pdfBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 1000);

    return { success: true };
  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : String(err);
    console.error('PDF export error:', errorMsg);
    return { success: false, message: `PDF export failed: ${errorMsg}` };
  }
}
