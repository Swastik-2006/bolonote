import { Note } from '../types';

const STORAGE_KEY = 'bolonote_saved_notes_v1';

const INITIAL_WELCOME_NOTE: Note = {
  id: 'welcome-sample-note',
  title: 'Welcome to BoloNote! 🎙️',
  transcript: 'Speak naturally. Your words become notes. Tap the microphone on the home screen to record notes in English, Hindi, Bengali, Marathi, or any of the 10 supported Indian languages.',
  language: 'English',
  languageCode: 'en-IN',
  createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
  durationSeconds: 8,
  isStarred: true,
};

export function getStoredNotes(): Note[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      // Seed with initial note
      localStorage.setItem(STORAGE_KEY, JSON.stringify([INITIAL_WELCOME_NOTE]));
      return [INITIAL_WELCOME_NOTE];
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return parsed;
    }
    return [];
  } catch (err) {
    console.error('Failed to load notes from localStorage', err);
    return [INITIAL_WELCOME_NOTE];
  }
}

export function saveStoredNote(note: Note): Note[] {
  try {
    const existing = getStoredNotes();
    const index = existing.findIndex((n) => n.id === note.id);
    let updated: Note[];
    if (index >= 0) {
      updated = [...existing];
      updated[index] = note;
    } else {
      updated = [note, ...existing];
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    return updated;
  } catch (err) {
    console.error('Failed to save note to localStorage', err);
    return getStoredNotes();
  }
}

export function deleteStoredNote(id: string): Note[] {
  try {
    const existing = getStoredNotes();
    const updated = existing.filter((n) => n.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    return updated;
  } catch (err) {
    console.error('Failed to delete note from localStorage', err);
    return getStoredNotes();
  }
}

export function clearAllStoredNotes(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (err) {
    console.error('Failed to clear notes', err);
  }
}

export function getStorageUsage(): { noteCount: number; kbUsed: string } {
  try {
    const raw = localStorage.getItem(STORAGE_KEY) || '';
    const bytes = new Blob([raw]).size;
    const kb = (bytes / 1024).toFixed(1);
    const notes = getStoredNotes();
    return { noteCount: notes.length, kbUsed: kb };
  } catch {
    return { noteCount: 0, kbUsed: '0' };
  }
}
