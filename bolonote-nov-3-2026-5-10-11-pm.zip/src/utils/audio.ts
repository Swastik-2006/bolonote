/**
 * Audio Recording, Visualizer & Transcription Services
 */

export interface TranscriptionResponse {
  success: boolean;
  configured: boolean;
  transcript?: string;
  confidence?: number;
  detectedLanguage?: string;
  error?: string;
  message?: string;
}

/**
 * Check if MediaRecorder is supported in current browser
 */
export function isAudioRecordingSupported(): boolean {
  return typeof window !== 'undefined' &&
    typeof navigator !== 'undefined' &&
    !!navigator.mediaDevices &&
    typeof navigator.mediaDevices.getUserMedia === 'function' &&
    typeof window.MediaRecorder !== 'undefined';
}

/**
 * Determine supported audio MIME type
 */
export function getSupportedMimeType(): string {
  const types = [
    'audio/webm;codecs=opus',
    'audio/webm',
    'audio/ogg;codecs=opus',
    'audio/mp4',
    'audio/wav',
  ];
  for (const type of types) {
    if (typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported(type)) {
      return type;
    }
  }
  return 'audio/webm';
}

/**
 * Convert Blob to Base64 string
 */
export function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      resolve(reader.result as string);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

/**
 * Call Server-Side Gnani Prisma v3.0 Speech-to-Text Integration Point
 */
export async function transcribeWithGnaniServer(
  audioBase64: string,
  mimeType: string,
  languageCode: string
): Promise<TranscriptionResponse> {
  try {
    const response = await fetch('/api/transcribe', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        audioBase64,
        mimeType,
        languageCode,
      }),
    });

    if (!response.ok) {
      const errorJson = await response.json().catch(() => ({}));
      return {
        success: false,
        configured: Boolean(errorJson.configured),
        error: errorJson.error || `HTTP ${response.status}`,
        message: errorJson.message || 'Server request failed',
      };
    }

    const data = await response.json();
    return data;
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : String(err);
    return {
      success: false,
      configured: false,
      error: 'NETWORK_ERROR',
      message: `Failed to connect to /api/transcribe: ${errorMsg}`,
    };
  }
}

/**
 * Text-to-Speech preview using Web SpeechSynthesis API with Indian language voice selection
 */
export function playTextToSpeech(
  text: string,
  langCode: string,
  onStart?: () => void,
  onEnd?: () => void,
  onError?: () => void
): () => void {
  if (typeof window === 'undefined' || !window.speechSynthesis) {
    onError?.();
    return () => {};
  }

  // Cancel any ongoing speech
  window.speechSynthesis.cancel();

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = langCode === 'auto' ? 'hi-IN' : langCode;
  utterance.rate = 0.95;
  utterance.pitch = 1.0;

  // Try to find matching voice
  const voices = window.speechSynthesis.getVoices();
  const matchedVoice = voices.find(
    (v) => v.lang.toLowerCase() === utterance.lang.toLowerCase() ||
           v.lang.toLowerCase().startsWith(utterance.lang.slice(0, 2).toLowerCase())
  );
  if (matchedVoice) {
    utterance.voice = matchedVoice;
  }

  utterance.onstart = () => onStart?.();
  utterance.onend = () => onEnd?.();
  utterance.onerror = () => {
    onEnd?.();
    onError?.();
  };

  window.speechSynthesis.speak(utterance);

  // Return cancel function
  return () => {
    window.speechSynthesis.cancel();
    onEnd?.();
  };
}

/**
 * Fetch Gnani Server status
 */
export async function fetchGnaniStatus() {
  try {
    const res = await fetch('/api/gnani/status');
    if (!res.ok) throw new Error('Status failed');
    return await res.json();
  } catch (err) {
    console.error('Failed to query Gnani status', err);
    return null;
  }
}

/**
 * Test Gnani API connection through server endpoint
 */
export async function testGnaniConnection(): Promise<{
  connected: boolean;
  status: 'Connected' | 'Not connected';
  message: string;
}> {
  try {
    const res = await fetch('/api/gnani/test-connection', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });
    if (!res.ok) {
      return {
        connected: false,
        status: 'Not connected',
        message: `Server returned HTTP ${res.status}`,
      };
    }
    return await res.json();
  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : String(err);
    return {
      connected: false,
      status: 'Not connected',
      message: `Failed to test connection: ${errorMsg}`,
    };
  }
}
