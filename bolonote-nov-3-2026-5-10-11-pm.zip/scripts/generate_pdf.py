#!/usr/bin/env python3
"""
High-fidelity multilingual PDF generator for BoloNote.
Uses Cairo, Pango, and HarfBuzz via standard C bindings to render
complex Indic text with native script shaping, ligatures, and embedded Noto fonts.
"""

import sys
import json
import math
import ctypes
from datetime import datetime

# Load Cairo and Pango shared libraries
try:
    cairo = ctypes.CDLL('libcairo.so.2')
    pango = ctypes.CDLL('libpango-1.0.so.0')
    pangocairo = ctypes.CDLL('libpangocairo-1.0.so.0')
except Exception as e:
    sys.stderr.write(f"Failed to load Cairo/Pango libraries: {e}\n")
    sys.exit(1)

# Cairo C API prototypes
cairo.cairo_pdf_surface_create.restype = ctypes.c_void_p
cairo.cairo_pdf_surface_create.argtypes = [ctypes.c_char_p, ctypes.c_double, ctypes.c_double]
cairo.cairo_create.restype = ctypes.c_void_p
cairo.cairo_create.argtypes = [ctypes.c_void_p]
cairo.cairo_surface_destroy.argtypes = [ctypes.c_void_p]
cairo.cairo_destroy.argtypes = [ctypes.c_void_p]
cairo.cairo_show_page.argtypes = [ctypes.c_void_p]
cairo.cairo_set_source_rgb.argtypes = [ctypes.c_void_p, ctypes.c_double, ctypes.c_double, ctypes.c_double]
cairo.cairo_rectangle.argtypes = [ctypes.c_void_p, ctypes.c_double, ctypes.c_double, ctypes.c_double, ctypes.c_double]
cairo.cairo_fill.argtypes = [ctypes.c_void_p]
cairo.cairo_move_to.argtypes = [ctypes.c_void_p, ctypes.c_double, ctypes.c_double]
cairo.cairo_arc.argtypes = [ctypes.c_void_p, ctypes.c_double, ctypes.c_double, ctypes.c_double, ctypes.c_double, ctypes.c_double]
cairo.cairo_close_path.argtypes = [ctypes.c_void_p]
cairo.cairo_new_sub_path.argtypes = [ctypes.c_void_p]

# Pango C API prototypes
pangocairo.pango_cairo_create_layout.restype = ctypes.c_void_p
pangocairo.pango_cairo_create_layout.argtypes = [ctypes.c_void_p]
pangocairo.pango_cairo_show_layout.argtypes = [ctypes.c_void_p, ctypes.c_void_p]

pango.pango_layout_set_text.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]
pango.pango_layout_set_width.argtypes = [ctypes.c_void_p, ctypes.c_int]
pango.pango_layout_set_wrap.argtypes = [ctypes.c_void_p, ctypes.c_int]
pango.pango_layout_set_alignment.argtypes = [ctypes.c_void_p, ctypes.c_int]
pango.pango_layout_get_pixel_size.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int)]

pango.pango_font_description_from_string.restype = ctypes.c_void_p
pango.pango_font_description_from_string.argtypes = [ctypes.c_char_p]
pango.pango_layout_set_font_description.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
pango.pango_font_description_free.argtypes = [ctypes.c_void_p]
pango.g_object_unref.argtypes = [ctypes.c_void_p]

# Pango Enums
PANGO_WRAP_WORD = 0
PANGO_ALIGN_LEFT = 0
PANGO_ALIGN_CENTER = 1
PANGO_ALIGN_RIGHT = 2

# Font family list with all 10 Indian scripts plus English/Latin
FONT_FAMILIES = (
    "Noto Sans, Noto Sans Bengali, Noto Sans Devanagari, "
    "Noto Sans Gujarati, Noto Sans Gurmukhi, Noto Sans Kannada, "
    "Noto Sans Malayalam, Noto Sans Tamil, Noto Sans Telugu, sans-serif"
)

def draw_rounded_rectangle(cr, x, y, w, h, r):
    cairo.cairo_new_sub_path(cr)
    cairo.cairo_arc(cr, x + w - r, y + r, r, -math.pi / 2, 0)
    cairo.cairo_arc(cr, x + w - r, y + h - r, r, 0, math.pi / 2)
    cairo.cairo_arc(cr, x + r, y + h - r, r, math.pi / 2, math.pi)
    cairo.cairo_arc(cr, x + r, y + r, r, math.pi, 3 * math.pi / 2)
    cairo.cairo_close_path(cr)
    cairo.cairo_fill(cr)

def draw_header_banner(cr, page_width, margin, notes_count, is_first_page=True):
    # Banner background: #FAF7F2 warm cream
    cairo.cairo_set_source_rgb(cr, 250 / 255.0, 247 / 255.0, 242 / 255.0)
    banner_height = 68.0 if is_first_page else 36.0
    cairo.cairo_rectangle(cr, 0.0, 0.0, page_width, banner_height)
    cairo.cairo_fill(cr)

    # Accent bottom border: #F3E8D2
    cairo.cairo_set_source_rgb(cr, 243 / 255.0, 232 / 255.0, 210 / 255.0)
    cairo.cairo_rectangle(cr, 0.0, banner_height - 1.0, page_width, 1.0)
    cairo.cairo_fill(cr)

    if is_first_page:
        # Title "BoloNote"
        desc_title = pango.pango_font_description_from_string(f"{FONT_FAMILIES} Bold 16".encode('utf-8'))
        layout = pangocairo.pango_cairo_create_layout(cr)
        pango.pango_layout_set_font_description(layout, desc_title)
        pango.pango_layout_set_text(layout, b"BoloNote", -1)
        cairo.cairo_set_source_rgb(cr, 41 / 255.0, 37 / 255.0, 36 / 255.0) # #292524
        cairo.cairo_move_to(cr, margin, 18.0)
        pangocairo.pango_cairo_show_layout(cr, layout)
        pango.g_object_unref(layout)
        pango.pango_font_description_free(desc_title)

        # Tagline
        desc_sub = pango.pango_font_description_from_string(f"{FONT_FAMILIES} 8.5".encode('utf-8'))
        layout = pangocairo.pango_cairo_create_layout(cr)
        pango.pango_layout_set_font_description(layout, desc_sub)
        pango.pango_layout_set_text(layout, b"Speak naturally. Your words become notes.", -1)
        cairo.cairo_set_source_rgb(cr, 120 / 255.0, 113 / 255.0, 108 / 255.0) # #78716C
        cairo.cairo_move_to(cr, margin, 42.0)
        pangocairo.pango_cairo_show_layout(cr, layout)
        pango.g_object_unref(layout)

        # Export metadata right-aligned
        today_str = datetime.now().strftime("%d %b %Y")
        meta_str = f"Exported: {today_str} · {notes_count} {'note' if notes_count == 1 else 'notes'}"
        layout = pangocairo.pango_cairo_create_layout(cr)
        pango.pango_layout_set_font_description(layout, desc_sub)
        pango.pango_layout_set_text(layout, meta_str.encode('utf-8'), -1)
        w = ctypes.c_int()
        h = ctypes.c_int()
        pango.pango_layout_get_pixel_size(layout, ctypes.byref(w), ctypes.byref(h))
        cairo.cairo_set_source_rgb(cr, 120 / 255.0, 113 / 255.0, 108 / 255.0)
        cairo.cairo_move_to(cr, page_width - margin - w.value, 42.0)
        pangocairo.pango_cairo_show_layout(cr, layout)
        pango.g_object_unref(layout)
        pango.pango_font_description_free(desc_sub)
    else:
        # Running header on subsequent pages
        desc_sub = pango.pango_font_description_from_string(f"{FONT_FAMILIES} 8".encode('utf-8'))
        layout = pangocairo.pango_cairo_create_layout(cr)
        pango.pango_layout_set_font_description(layout, desc_sub)
        pango.pango_layout_set_text(layout, b"BoloNote \xe2\x80\x94 Voice Notes Export", -1)
        cairo.cairo_set_source_rgb(cr, 150 / 255.0, 145 / 255.0, 140 / 255.0)
        cairo.cairo_move_to(cr, margin, 12.0)
        pangocairo.pango_cairo_show_layout(cr, layout)
        pango.g_object_unref(layout)
        pango.pango_font_description_free(desc_sub)

def generate_pdf(notes, output_path):
    PAGE_WIDTH = 595.28 # A4 width in pt
    PAGE_HEIGHT = 841.89 # A4 height in pt
    MARGIN = 40.0
    CONTENT_WIDTH = PAGE_WIDTH - MARGIN * 2.0

    surface = cairo.cairo_pdf_surface_create(output_path.encode('utf-8'), PAGE_WIDTH, PAGE_HEIGHT)
    cr = cairo.cairo_create(surface)

    # Reusable font descriptions
    desc_note_title = pango.pango_font_description_from_string(f"{FONT_FAMILIES} Bold 10".encode('utf-8'))
    desc_note_meta = pango.pango_font_description_from_string(f"{FONT_FAMILIES} 8".encode('utf-8'))
    desc_note_body = pango.pango_font_description_from_string(f"{FONT_FAMILIES} 9.5".encode('utf-8'))

    # Initial page header
    draw_header_banner(cr, PAGE_WIDTH, MARGIN, len(notes), is_first_page=True)
    y = 86.0
    page_number = 1

    for idx, note in enumerate(notes):
        title = (note.get('title') or f"Untitled Voice Note {idx + 1}").strip()
        transcript = (note.get('transcript') or "(No transcript content)").strip()
        created_at = note.get('createdAt') or datetime.now().isoformat()
        try:
            dt = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
            date_formatted = dt.strftime("%d %b %Y, %H:%M")
        except Exception:
            date_formatted = created_at[:16].replace('T', ' ')

        language = note.get('language') or 'Voice Note'
        duration = int(note.get('durationSeconds') or 0)
        meta_info = f"{language} · {duration}s · {date_formatted}"

        # 1. Prepare body layout to measure required height
        body_layout = pangocairo.pango_cairo_create_layout(cr)
        pango.pango_layout_set_font_description(body_layout, desc_note_body)
        pango.pango_layout_set_width(body_layout, int((CONTENT_WIDTH - 16.0) * 1024))
        pango.pango_layout_set_wrap(body_layout, PANGO_WRAP_WORD)
        pango.pango_layout_set_text(body_layout, transcript.encode('utf-8'), -1)

        body_w = ctypes.c_int()
        body_h = ctypes.c_int()
        pango.pango_layout_get_pixel_size(body_layout, ctypes.byref(body_w), ctypes.byref(body_h))

        card_header_height = 24.0
        total_note_height = card_header_height + 8.0 + body_h.value + 16.0

        # Check if we need a new page
        if y + card_header_height + 30.0 > PAGE_HEIGHT - MARGIN:
            cairo.cairo_show_page(cr)
            page_number += 1
            draw_header_banner(cr, PAGE_WIDTH, MARGIN, len(notes), is_first_page=False)
            y = 50.0

        # Draw Note Header Pill Card
        cairo.cairo_set_source_rgb(cr, 244 / 255.0, 240 / 255.0, 235 / 255.0) # #F4F0EB
        draw_rounded_rectangle(cr, MARGIN, y, CONTENT_WIDTH, card_header_height, 4.0)

        # Title text in card
        title_layout = pangocairo.pango_cairo_create_layout(cr)
        pango.pango_layout_set_font_description(title_layout, desc_note_title)
        # Limit title width so it doesn't collide with metadata
        pango.pango_layout_set_width(title_layout, int((CONTENT_WIDTH * 0.58) * 1024))
        pango.pango_layout_set_wrap(title_layout, PANGO_WRAP_WORD)
        pango.pango_layout_set_text(title_layout, title.encode('utf-8'), -1)
        cairo.cairo_set_source_rgb(cr, 41 / 255.0, 37 / 255.0, 36 / 255.0)
        cairo.cairo_move_to(cr, MARGIN + 8.0, y + 5.0)
        pangocairo.pango_cairo_show_layout(cr, title_layout)
        pango.g_object_unref(title_layout)

        # Metadata text in card (right aligned)
        meta_layout = pangocairo.pango_cairo_create_layout(cr)
        pango.pango_layout_set_font_description(meta_layout, desc_note_meta)
        pango.pango_layout_set_text(meta_layout, meta_info.encode('utf-8'), -1)
        mw = ctypes.c_int()
        mh = ctypes.c_int()
        pango.pango_layout_get_pixel_size(meta_layout, ctypes.byref(mw), ctypes.byref(mh))
        cairo.cairo_set_source_rgb(cr, 115 / 255.0, 115 / 255.0, 115 / 255.0)
        cairo.cairo_move_to(cr, PAGE_WIDTH - MARGIN - mw.value - 8.0, y + 6.5)
        pangocairo.pango_cairo_show_layout(cr, meta_layout)
        pango.g_object_unref(meta_layout)

        y += card_header_height + 8.0

        # Draw Note Body (handles pagination for multi-page transcripts if needed)
        cairo.cairo_set_source_rgb(cr, 55 / 255.0, 65 / 255.0, 81 / 255.0) # #374151
        cairo.cairo_move_to(cr, MARGIN + 8.0, y)
        pangocairo.pango_cairo_show_layout(cr, body_layout)
        pango.g_object_unref(body_layout)

        y += body_h.value + 16.0

    # Finalize document
    cairo.cairo_show_page(cr)

    pango.pango_font_description_free(desc_note_title)
    pango.pango_font_description_free(desc_note_meta)
    pango.pango_font_description_free(desc_note_body)

    cairo.cairo_destroy(cr)
    cairo.cairo_surface_destroy(surface)

if __name__ == '__main__':
    if len(sys.argv) < 3:
        sys.stderr.write("Usage: generate_pdf.py <input_json_path> <output_pdf_path>\n")
        sys.exit(1)

    input_path = sys.argv[1]
    output_path = sys.argv[2]

    with open(input_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    notes = data if isinstance(data, list) else data.get('notes', [])
    generate_pdf(notes, output_path)
    print(f"SUCCESS: Generated {output_path}")
